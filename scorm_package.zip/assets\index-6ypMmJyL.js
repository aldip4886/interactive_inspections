(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))i(s);new MutationObserver(s=>{for(const a of s)if(a.type==="childList")for(const n of a.addedNodes)n.tagName==="LINK"&&n.rel==="modulepreload"&&i(n)}).observe(document,{childList:!0,subtree:!0});function t(s){const a={};return s.integrity&&(a.integrity=s.integrity),s.referrerPolicy&&(a.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?a.credentials="include":s.crossOrigin==="anonymous"?a.credentials="omit":a.credentials="same-origin",a}function i(s){if(s.ep)return;s.ep=!0;const a=t(s);fetch(s.href,a)}})();class y{constructor(){this.api=null,this.version=null,this.isInitialized=!1,this.learnerName="",this.learnerId=""}findAPI(e){let t=0,i=e;for(;i&&t<10;){if(i.API_1484_11)return this.version="2004",i.API_1484_11;if(i.API)return this.version="1.2",i.API;if(i.parent&&i.parent!==i)i=i.parent;else if(i.opener)i=i.opener;else break;t++}return null}init(){if(this.api=this.findAPI(window),!this.api)return console.warn("[SCORM] No SCORM API found. Running in standalone LMS simulation mode."),!1;try{let e=!1;this.version==="2004"?e=this.api.Initialize(""):this.version==="1.2"&&(e=this.api.LMSInitialize("")),this.isInitialized=e==="true"||e===!0,this.isInitialized?(this.fetchLearnerInfo(),console.log(`[SCORM] Successfully initialized SCORM ${this.version} API.`)):console.error("[SCORM] API Initialize failed.")}catch(e){console.error("[SCORM] Exception during initialization:",e)}return this.isInitialized}fetchLearnerInfo(){this.isInitialized&&(this.version==="2004"?(this.learnerName=this.getValue("cmi.learner_name"),this.learnerId=this.getValue("cmi.learner_id")):(this.learnerName=this.getValue("cmi.core.student_name"),this.learnerId=this.getValue("cmi.core.student_id")))}getValue(e){if(!this.isInitialized||!this.api)return"";try{return this.version==="2004"?this.api.GetValue(e):this.api.LMSGetValue(e)}catch(t){return console.error(`[SCORM] GetValue failed for ${e}`,t),""}}setValue(e,t){if(!this.isInitialized||!this.api)return!1;try{let i;return this.version==="2004"?i=this.api.SetValue(e,String(t)):i=this.api.LMSSetValue(e,String(t)),i==="true"||i===!0}catch(i){return console.error(`[SCORM] SetValue failed for ${e}`,i),!1}}commit(){if(!this.isInitialized||!this.api)return!1;try{return this.version==="2004"?this.api.Commit("")==="true":this.api.LMSCommit("")==="true"}catch(e){return console.error("[SCORM] Commit failed",e),!1}}terminate(){if(!this.isInitialized||!this.api)return!1;try{let e;return this.version==="2004"?e=this.api.Terminate(""):e=this.api.LMSFinish(""),this.isInitialized=!1,e==="true"||e===!0}catch(e){return console.error("[SCORM] Terminate failed",e),!1}}setBookmark(e){this.version==="2004"?this.setValue("cmi.location",e):this.setValue("cmi.core.lesson_location",e),this.commit()}getBookmark(){return this.version==="2004"?this.getValue("cmi.location"):this.getValue("cmi.core.lesson_location")}setCompleted(e=100){this.version==="2004"?(this.setValue("cmi.completion_status","completed"),this.setValue("cmi.success_status",e>=70?"passed":"failed"),this.setValue("cmi.score.scaled",(e/100).toFixed(2)),this.setValue("cmi.score.raw",e),this.setValue("cmi.score.min","0"),this.setValue("cmi.score.max","100")):(this.setValue("cmi.core.lesson_status",e>=70?"passed":"completed"),this.setValue("cmi.core.score.raw",e)),this.commit()}}const p=new y;class k{constructor(){this._profile=null,this._isLoaded=!1,this._authMethod="UNINITIALIZED",this.DEFAULT_PROFILE={username:"pegawai_djbc",nip:"199001012015011001",name:"Pegawai DJBC (Simulasi)",email:"pegawai.djbc@kemenkeu.go.id",role:"PEGAWAI",avatarUrl:"",unit:"Direktorat Jenderal Bea dan Cukai",organisasi:"Kementerian Keuangan RI"}}async init(){if(this._isLoaded)return this._profile;try{const s=await fetch("/office/api/auth/session",{credentials:"include"});if(s.ok){const a=await s.json();if(a&&(a.user||a.username||a.name)){const n=a.user||a;return this._profile={username:n.username||n.nip||n.email||"pegawai_klc",nip:n.nip||n.username||"",name:n.name||n.nama||n.displayName||"Pegawai DJBC",email:n.email||`${n.username||"pegawai"}@kemenkeu.go.id`,role:(n.role||n.jabatan||"PEGAWAI").toUpperCase(),avatarUrl:n.avatarUrl||n.avatar||n.foto||"",unit:n.unit||n.unitKerja||"Direktorat Jenderal Bea dan Cukai",organisasi:n.organisasi||"Kementerian Keuangan RI"},this._authMethod="SESSION_API",this._isLoaded=!0,this.updateDOM(),this._profile}}}catch{}const e=new URLSearchParams(window.location.search);if(e.has("username")||e.has("nip"))return this._profile={username:e.get("username")||e.get("nip"),nip:e.get("nip")||e.get("username"),name:e.get("name")||e.get("username")||"Pegawai DJBC",email:e.get("email")||"pegawai@kemenkeu.go.id",role:(e.get("role")||"PEGAWAI").toUpperCase(),avatarUrl:e.get("avatar")||"",unit:"Direktorat Jenderal Bea dan Cukai",organisasi:"Kementerian Keuangan RI"},this._authMethod="URL_PARAMS",this._isLoaded=!0,this.updateDOM(),this._profile;const t=window.scormInstance?window.scormInstance.learnerName:"",i=window.scormInstance?window.scormInstance.learnerId:"";return t||i?(this._profile={username:i||"scorm_user",nip:i||"",name:t||"Pegawai SCORM",email:`${i||"pegawai"}@kemenkeu.go.id`,role:"PEGAWAI",avatarUrl:"",unit:"Direktorat Jenderal Bea dan Cukai",organisasi:"Kementerian Keuangan RI"},this._authMethod="SCORM_API",this._isLoaded=!0,this.updateDOM(),this._profile):(this._profile={...this.DEFAULT_PROFILE},this._authMethod="DEFAULT_FALLBACK",this._isLoaded=!0,this.updateDOM(),this._profile)}getProfile(){return this._profile||this.DEFAULT_PROFILE}getAuthMethod(){return this._authMethod}getActorForXAPI(){const e=this.getProfile();return{objectType:"Agent",name:e.name,mbox:`mailto:${e.email}`,account:{homePage:"https://klc2.kemenkeu.go.id",name:e.username||e.nip}}}updateDOM(){const e=this.getProfile(),t=document.getElementById("user-display-name"),i=document.getElementById("user-display-role"),s=document.getElementById("user-avatar-img"),a=document.getElementById("user-avatar-placeholder"),n=document.getElementById("user-avatar-initials");if(t&&(t.textContent=e.name),i&&(i.textContent=`${e.role} — ${e.unit}`),e.avatarUrl&&s)s.src=e.avatarUrl,s.style.display="block",a&&(a.style.display="none"),n&&(n.style.display="none");else if(n){s&&(s.style.display="none"),a&&(a.style.display="none"),n.style.display="block";const o=e.name.split(" ").map(r=>r[0]).join("").substring(0,2).toUpperCase();n.textContent=o||"BC"}}}const u=new k;class x{constructor(){this.STORAGE_KEY="djbc_lrs_config",this.config=this.loadConfig()}loadConfig(){try{const e=localStorage.getItem(this.STORAGE_KEY);if(e)return JSON.parse(e)}catch(e){console.error("[LRSConfig] Failed to load config",e)}return{endpoint:"",username:"",password:"",enabled:!1}}saveConfig(e,t,i,s=!0){let a=(e||"").trim();a&&!a.endsWith("/")&&(a+="/"),this.config={endpoint:a,username:(t||"").trim(),password:(i||"").trim(),enabled:!!s};try{localStorage.setItem(this.STORAGE_KEY,JSON.stringify(this.config))}catch(n){console.error("[LRSConfig] Failed to save config",n)}return this.config}getConfig(){return{...this.config}}isConfigured(){return!!(this.config.enabled&&this.config.endpoint&&this.config.username)}getAuthHeader(){return!this.config.username||!this.config.password?"":"Basic "+btoa(`${this.config.username}:${this.config.password}`)}async testConnection(e,t,i){let s=(e||"").trim();s.endsWith("/")||(s+="/"),s+="about";const a={"X-Experience-API-Version":"1.0.3"};t&&i&&(a.Authorization="Basic "+btoa(`${t}:${i}`));try{const n=await fetch(s,{method:"GET",headers:a});return n.ok?{success:!0,message:"Koneksi ke LRS berhasil!",version:(await n.json().catch(()=>({}))).version||["1.0.3"]}:{success:!1,message:`LRS merespon HTTP ${n.status} (${n.statusText})`}}catch(n){return{success:!1,message:`Gagal menghubungi LRS: ${n.message}`}}}}const c=new x;class w{constructor(){this.BASE_URL=window.location.origin+window.location.pathname}getVerbs(){return{launched:{id:"http://adlnet.gov/expapi/verbs/launched",display:{"id-ID":"memulai"}},initialized:{id:"http://adlnet.gov/expapi/verbs/initialized",display:{"id-ID":"menginisialisasi"}},interacted:{id:"http://adlnet.gov/expapi/verbs/interacted",display:{"id-ID":"berinteraksi"}},viewed:{id:"http://id.tincanapi.com/verb/viewed",display:{"id-ID":"melihat"}},answered:{id:"http://adlnet.gov/expapi/verbs/answered",display:{"id-ID":"menjawab"}},completed:{id:"http://adlnet.gov/expapi/verbs/completed",display:{"id-ID":"menyelesaikan"}},passed:{id:"http://adlnet.gov/expapi/verbs/passed",display:{"id-ID":"lulus"}},failed:{id:"http://adlnet.gov/expapi/verbs/failed",display:{"id-ID":"gagal"}}}}buildStatement({verb:e,activityId:t,activityName:i,activityDesc:s,result:a,contextExtensions:n}){const r={actor:u.getActorForXAPI(),verb:e,object:{objectType:"Activity",id:`${this.BASE_URL}#/${t}`,definition:{name:{"id-ID":i,"en-US":i},description:{"id-ID":s||i}}},timestamp:new Date().toISOString(),context:{registration:this.getRegistrationId(),contextActivities:{parent:[{id:`${this.BASE_URL}#/module-inspection-suite`,definition:{name:{"id-ID":"Modul Interaktif Penyelundupan Narkotika DJBC"}}}]},extensions:{"http://klc2.kemenkeu.go.id/xapi/extensions/unit":u.getProfile().unit,"http://klc2.kemenkeu.go.id/xapi/extensions/role":u.getProfile().role,...n||{}}}};return a&&(r.result=a),r}getRegistrationId(){let e=sessionStorage.getItem("xapi_registration_id");return e||(e="reg-"+Math.random().toString(36).substring(2,11)+"-"+Date.now(),sessionStorage.setItem("xapi_registration_id",e)),e}async sendStatement(e){if(console.log("[xAPI Statement Generated]",e),!c.isConfigured())return{sent:!1,reason:"LRS not configured or disabled"};const i=c.getConfig().endpoint+"statements";try{const s=await fetch(i,{method:"POST",headers:{"Content-Type":"application/json","X-Experience-API-Version":"1.0.3",Authorization:c.getAuthHeader()},body:JSON.stringify(e)});return s.ok?(console.log("[xAPI Statement Successfully Sent to LRS]"),{sent:!0}):(console.warn(`[xAPI Send Failed] HTTP ${s.status}`,await s.text().catch(()=>"")),{sent:!1,reason:`HTTP ${s.status}`})}catch(s){return console.error("[xAPI Exception]",s),{sent:!1,reason:s.message}}}trackModuleView(e,t){const i=this.getVerbs(),s=this.buildStatement({verb:i.launched,activityId:e,activityName:`Modul Inspeksi: ${t}`,activityDesc:`Peserta membuka halaman modul ${t}`});this.sendStatement(s)}trackHotspotClick(e,t,i,s){const a=this.getVerbs(),n=this.buildStatement({verb:a.interacted,activityId:`${e}/hotspot/${t}`,activityName:`Hotspot: ${i}`,activityDesc:`Peserta mengeklik hotspot ${i} pada modul ${e}`,contextExtensions:{"http://klc2.kemenkeu.go.id/xapi/extensions/category":s,"http://klc2.kemenkeu.go.id/xapi/extensions/module":e}});this.sendStatement(n)}trackQuizCompleted(e,t,i){const s=this.getVerbs(),a=t?s.passed:s.failed,n=this.buildStatement({verb:a,activityId:"evaluasi-narkotika-djbc",activityName:"Ujian Evaluasi Modus Penyelundupan Narkotika",result:{score:{scaled:(e/100).toFixed(2),raw:e,min:0,max:100},success:t,completion:!0}});this.sendStatement(n)}}const m=new w;class b{constructor(e){this.container=e}async render(){const e=u.getProfile(),t=`
      <div style="width: 100%; height: 100%; overflow-y: auto; padding: 32px; display: flex; flex-direction: column; gap: 32px; max-width: 1280px; margin: 0 auto;">
        
        <!-- Hero Section -->
        <div style="background: linear-gradient(135deg, rgba(18, 34, 56, 0.9) 0%, rgba(10, 22, 40, 0.95) 100%); border: 1px solid var(--surface-glass-border); border-radius: var(--radius-xl); padding: 36px; display: flex; align-items: center; justify-content: space-between; box-shadow: var(--shadow-lg); position: relative; overflow: hidden;">
          <div style="position: absolute; right: -40px; top: -40px; width: 300px; height: 300px; background: var(--accent-gold-glow); filter: blur(80px); border-radius: 50%; pointer-events: none;"></div>

          <div style="max-width: 720px; z-index: 1;">
            <div class="badge badge-gold" style="margin-bottom: 12px; font-size: 0.8rem;">E-LEARNING INTERAKTIF DJBC 2026</div>
            <h1 style="font-size: 2.2rem; margin-bottom: 12px; color: #FFF; line-height: 1.2;">
              Inspeksi Modus Penyelundupan Narkotika
            </h1>
            <p style="font-size: 1rem; color: var(--text-secondary); line-height: 1.6; margin-bottom: 24px;">
              Selamat datang, <strong style="color: var(--accent-gold);">${e.name}</strong> (${e.nip||e.username}). Modul ini dirancang khusus untuk meningkatkan kapabilitas teknis pegawai Direktorat Jenderal Bea dan Cukai dalam mendeteksi dan menginspeksi titik-titik penyembunyian Narkotika pada 4 moda pemeriksaan utama.
            </p>
            <div style="display: flex; gap: 16px;">
              <a href="#/modul1" class="btn btn-gold">
                🚀 Mulai Pembelajaran (Modul 1)
              </a>
              <a href="#/evaluasi" class="btn btn-outline">
                📝 Ujian Evaluasi
              </a>
            </div>
          </div>

          <div style="display: flex; flex-direction: column; gap: 12px; z-index: 1; min-width: 220px; background: rgba(0,0,0,0.3); padding: 20px; border-radius: var(--radius-lg); border: 1px solid var(--surface-glass-border);">
            <div style="font-size: 0.78rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">STATUS ANALYTICS xAPI</div>
            <div style="display: flex; align-items: center; gap: 10px;">
              <span style="width: 10px; height: 10px; border-radius: 50%; background: #34C759;"></span>
              <span style="font-size: 0.85rem; font-weight: 600; color: #FFF;">KLC Session Connected</span>
            </div>
            <div style="font-size: 0.75rem; color: var(--text-secondary);">
              Metode Auth: <code style="color: var(--accent-gold);">${u.getAuthMethod()}</code>
            </div>
          </div>
        </div>

        <!-- 4 Key Modules Cards -->
        <div>
          <h2 style="font-size: 1.3rem; color: #FFF; margin-bottom: 16px;">Kategori Modul Inspeksi Interaktif</h2>
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px;">
            
            <!-- Modul 1 Card -->
            <a href="#/modul1" style="text-decoration: none; color: inherit;">
              <div class="card-hover" style="background: var(--bg-dark-800); border: 1px solid var(--surface-glass-border); border-radius: var(--radius-lg); padding: 24px; display: flex; flex-direction: column; gap: 12px; transition: transform 0.2s, border-color 0.2s;">
                <div style="font-size: 2.2rem;">👤</div>
                <h3 style="font-size: 1.1rem; color: #FFF; margin: 0;">1. Tubuh Kurir</h3>
                <p style="font-size: 0.85rem; color: var(--text-secondary); margin: 0; line-height: 1.5;">
                  Inspeksi anatomi & X-Ray tubuh kurir: Body Packing (swallowing pellets), Body Strapping, dan Insertion.
                </p>
                <div style="font-size: 0.8rem; font-weight: 600; color: var(--accent-gold); margin-top: auto;">Buka Modul 1 &rarr;</div>
              </div>
            </a>

            <!-- Modul 2 Card -->
            <a href="#/modul2" style="text-decoration: none; color: inherit;">
              <div class="card-hover" style="background: var(--bg-dark-800); border: 1px solid var(--surface-glass-border); border-radius: var(--radius-lg); padding: 24px; display: flex; flex-direction: column; gap: 12px; transition: transform 0.2s, border-color 0.2s;">
                <div style="font-size: 2.2rem;">🧳</div>
                <h3 style="font-size: 1.1rem; color: #FFF; margin: 0;">2. Barang Bawaan</h3>
                <p style="font-size: 0.85rem; color: var(--text-secondary); margin: 0; line-height: 1.5;">
                  Pemeriksaan koper bagasi penumpang: False Bottom, Dinding Ganda, Rangka Trolley, & Lipatan Jahitan.
                </p>
                <div style="font-size: 0.8rem; font-weight: 600; color: var(--accent-gold); margin-top: auto;">Buka Modul 2 &rarr;</div>
              </div>
            </a>

            <!-- Modul 3 Card -->
            <a href="#/modul3" style="text-decoration: none; color: inherit;">
              <div class="card-hover" style="background: var(--bg-dark-800); border: 1px solid var(--surface-glass-border); border-radius: var(--radius-lg); padding: 24px; display: flex; flex-direction: column; gap: 12px; transition: transform 0.2s, border-color 0.2s;">
                <div style="font-size: 2.2rem;">📦</div>
                <h3 style="font-size: 1.1rem; color: #FFF; margin: 0;">3. Barang Kiriman</h3>
                <p style="font-size: 0.85rem; color: var(--text-secondary); margin: 0; line-height: 1.5;">
                  Inspeksi kargo Pos & PJT: Kaleng Makanan Palsu (Liquid Meth), Kardus Corrugated, & Elektronik.
                </p>
                <div style="font-size: 0.8rem; font-weight: 600; color: var(--accent-gold); margin-top: auto;">Buka Modul 3 &rarr;</div>
              </div>
            </a>

            <!-- Modul 4A & 4B Card -->
            <a href="#/modul4a" style="text-decoration: none; color: inherit;">
              <div class="card-hover" style="background: var(--bg-dark-800); border: 1px solid var(--surface-glass-border); border-radius: var(--radius-lg); padding: 24px; display: flex; flex-direction: column; gap: 12px; transition: transform 0.2s, border-color 0.2s;">
                <div style="font-size: 2.2rem;">🚗 🚢</div>
                <h3 style="font-size: 1.1rem; color: #FFF; margin: 0;">4. Sarana Pengangkut</h3>
                <p style="font-size: 0.85rem; color: var(--text-secondary); margin: 0; line-height: 1.5;">
                  Pemeriksaan Kompartemen Pintu Mobil, Tangki Bahan Bakar Dinding Ganda, Kontainer Reefer, & Kapal Laut.
                </p>
                <div style="font-size: 0.8rem; font-weight: 600; color: var(--accent-gold); margin-top: auto;">Buka Modul 4 &rarr;</div>
              </div>
            </a>

          </div>
        </div>

        <!-- Instructions Section -->
        <div style="background: rgba(255,255,255,0.02); border: 1px solid var(--surface-glass-border); border-radius: var(--radius-lg); padding: 24px;">
          <h3 style="font-size: 1.1rem; color: var(--accent-gold); margin-bottom: 12px;">📌 Panduan Navigasi & Fitur Modul</h3>
          <ul style="color: var(--text-secondary); font-size: 0.9rem; line-height: 1.8; margin-left: 20px;">
            <li>Gunakan tombol <strong>X-Ray View / Cutaway View</strong> untuk beralih antara tampilan fisik normal dan tampilan sinar-X / penampang irisan.</li>
            <li>Klik atau hover <strong>Hotspot Berpendar (Pulse Marker)</strong> di layar untuk melihat gambar visual realistis modus, indikator risiko, dan SOP tindakan Bea Cukai.</li>
            <li>Gunakan <strong>Bottom Thumbnail Carousel</strong> untuk melompat langsung ke titik penyembunyian tertentu.</li>
            <li>Selesaikan seluruh modul interaktif kemudian ikuti <strong>Ujian Evaluasi</strong> untuk mendapatkan kelulusan SCORM & xAPI.</li>
          </ul>
        </div>

      </div>
    `;this.container.innerHTML=t,m.trackModuleView("beranda","Beranda & Panduan Inspeksi")}}class I{constructor(e,{onHotspotClick:t}){this.container=e,this.onHotspotClick=t,this.visitedSet=new Set,this.activeFilter="all",this.activeView="front",this.hotspots=[]}render(e,t="front",i="all"){this.hotspots=e,this.activeView=t,this.activeFilter=i;const s=e.filter(a=>{const n=a.view?a.view===t:!0,o=i==="all"||a.category===i;return n&&o});this.container.innerHTML=s.map(a=>`
        <div class="hotspot-marker ${this.visitedSet.has(a.id)?"visited":""} animate-fade-in" 
             data-id="${a.id}" 
             style="left: ${a.position.x}%; top: ${a.position.y}%;">
          <div class="hotspot-pulse"></div>
          <div class="hotspot-inner"></div>
          <div class="hotspot-tooltip">${a.label}</div>
        </div>
      `).join(""),this.attachEvents()}attachEvents(){this.container.querySelectorAll(".hotspot-marker").forEach(t=>{t.addEventListener("click",i=>{i.stopPropagation();const s=t.getAttribute("data-id");this.visitedSet.add(s),t.classList.add("visited");const a=this.hotspots.find(n=>n.id===s);a&&this.onHotspotClick&&this.onHotspotClick(a)})})}markVisited(e){this.visitedSet.add(e);const t=this.container.querySelector(`.hotspot-marker[data-id="${e}"]`);t&&t.classList.add("visited")}getVisitedCount(){return this.visitedSet.size}}class S{constructor(e){this.drawer=e,this.currentData=null}show(e){this.currentData=e;const t=e.badgeType?`badge-${e.badgeType}`:"badge-danger",i=(e.riskIndicators||[]).map(o=>`
      <div class="risk-item">
        <span>⚠️</span>
        <div>${o}</div>
      </div>
    `).join(""),s=(e.inspectionActions||[]).map(o=>`
      <div class="action-item">
        <span>🔍</span>
        <div>${o}</div>
      </div>
    `).join(""),a=`
      <div class="drawer-header">
        <div>
          <span class="badge ${t}" style="margin-bottom: 8px;">${e.badge||"MODUS PENYELUNDUPAN"}</span>
          <h3 style="margin: 0; font-size: 1.15rem; color: #FFF; line-height: 1.3;">${e.label}</h3>
        </div>
        <button id="close-info-drawer-btn" class="btn-icon" style="width:32px; height:32px; flex-shrink: 0;">✕</button>
      </div>

      <div class="drawer-body">
        <!-- Hotspot Main Realistic Image -->
        <div class="drawer-image-container">
          <img src="${e.mainImage}" alt="${e.label}" 
               onerror="this.onerror=null; this.src='assets/images/central/m1_body_front_xray.png';">
          <div style="position: absolute; bottom: 8px; right: 8px; background: rgba(0,0,0,0.7); padding: 2px 8px; border-radius: 4px; font-size: 0.68rem; color: #FFF;">
            Visual Modus Realistis
          </div>
        </div>

        <!-- Deskripsi Modus -->
        <div>
          <h4 style="font-size: 0.9rem; color: var(--accent-gold); margin-bottom: 6px;">Deskripsi Modus Penyelundupan</h4>
          <p style="font-size: 0.85rem; color: var(--text-primary); line-height: 1.6;">${e.description}</p>
        </div>

        <!-- Indikator Resiko / Anomali -->
        <div>
          <h4 style="font-size: 0.9rem; color: #FF9500; margin-bottom: 6px;">Indikator Risiko & Anomali (Red Flags)</h4>
          <div class="risk-list">
            ${i}
          </div>
        </div>

        <!-- Tindakan Inspeksi DJBC -->
        <div>
          <h4 style="font-size: 0.9rem; color: var(--accent-cyan); margin-bottom: 6px;">SOP Tindakan Inspeksi Bea Cukai</h4>
          <div class="action-list">
            ${s}
          </div>
        </div>
      </div>
    `;this.drawer.innerHTML=a,this.drawer.classList.add("open");const n=this.drawer.querySelector("#close-info-drawer-btn");n&&n.addEventListener("click",()=>this.hide())}hide(){this.drawer.classList.remove("open")}}class E{constructor(e,{onViewChange:t}){this.container=e,this.onViewChange=t,this.currentViewKey=""}render(e,t){this.currentViewKey=t;const i=Object.keys(e||{});if(i.length<=1){this.container.innerHTML="";return}const s=`
      <div class="view-mode-toggle">
        ${i.map(a=>{const n=e[a];return`
            <button class="view-mode-btn ${a===t?"active":""}" data-key="${a}">
              ${n.label||a.toUpperCase()}
            </button>
          `}).join("")}
      </div>
    `;this.container.innerHTML=s,this.attachEvents()}attachEvents(){const e=this.container.querySelectorAll(".view-mode-btn");e.forEach(t=>{t.addEventListener("click",()=>{const i=t.getAttribute("data-key");i&&i!==this.currentViewKey&&(this.currentViewKey=i,e.forEach(s=>s.classList.remove("active")),t.classList.add("active"),this.onViewChange&&this.onViewChange(i))})})}}class L{constructor(e,{onSelectHotspot:t}){this.container=e,this.onSelectHotspot=t,this.activeId=null}render(e,t=null){if(this.activeId=t,!e||e.length===0){this.container.innerHTML="";return}const i=`
      <div class="bottom-carousel-bar">
        <div style="font-size: 0.75rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase; padding-right: 8px; white-space: nowrap;">
          DAFTAR HOTSPOT:
        </div>
        ${e.map(s=>`
            <div class="carousel-thumb ${s.id===t?"active":""}" data-id="${s.id}">
              <img src="${s.mainImage}" alt="${s.label}" onerror="this.onerror=null; this.src='assets/images/central/m1_body_front_xray.png';">
              <div class="carousel-thumb-title">${s.label}</div>
            </div>
          `).join("")}
      </div>
    `;this.container.innerHTML=i,this.attachEvents(e)}attachEvents(e){const t=this.container.querySelectorAll(".carousel-thumb");t.forEach(i=>{i.addEventListener("click",()=>{const s=i.getAttribute("data-id"),a=e.find(n=>n.id===s);a&&this.onSelectHotspot&&(t.forEach(n=>n.classList.remove("active")),i.classList.add("active"),this.onSelectHotspot(a))})})}}class g{constructor(e,t){this.container=e,this.jsonPath=t,this.moduleData=null,this.activeView="",this.activeFilter="all"}async loadData(){try{const e=await fetch(this.jsonPath);this.moduleData=await e.json()}catch(e){console.error(`[BaseModule] Failed to load JSON ${this.jsonPath}`,e)}}async render(){if(this.moduleData||await this.loadData(),!this.moduleData)return;const e=this.moduleData,t=Object.keys(e.centralImages||{});this.activeView=t[0]||"front";const i=`
      <div class="inspection-workspace">
        <!-- Floating Filter Category Bar -->
        <div class="filter-category-bar">
          ${(e.filterCategories||[]).map(s=>`
            <button class="filter-btn ${s.id==="all"?"active":""}" data-filter="${s.id}">
              ${s.label}
            </button>
          `).join("")}
        </div>

        <!-- Floating Viewport Controls (X-Ray / Normal) -->
        <div id="view-toggle-container"></div>

        <!-- Central Inspection Viewport Scene -->
        <div class="scene-viewport">
          <div class="scene-container">
            <img id="central-scene-image" class="scene-image" 
                 src="${e.centralImages[this.activeView].url}" 
                 alt="${e.centralImages[this.activeView].label}">
            
            <!-- Hotspots Interactive Layer -->
            <div id="hotspot-layer-root"></div>
          </div>
        </div>

        <!-- Bottom Carousel Bar -->
        <div id="carousel-root"></div>

        <!-- Right Side Info Drawer -->
        <aside id="info-panel-drawer"></aside>
      </div>
    `;this.container.innerHTML=i,this.initComponents(),m.trackModuleView(e.moduleId,e.moduleTitle)}initComponents(){const e=this.moduleData,t=document.getElementById("central-scene-image"),i=document.getElementById("info-panel-drawer"),s=document.getElementById("hotspot-layer-root"),a=document.getElementById("view-toggle-container"),n=document.getElementById("carousel-root");this.infoPanel=new S(i),this.hotspotLayer=new I(s,{onHotspotClick:r=>{this.infoPanel.show(r),this.carousel.render(e.hotspots,r.id),m.trackHotspotClick(e.moduleId,r.id,r.label,r.category)}}),this.viewToggle=new E(a,{onViewChange:r=>{this.activeView=r,e.centralImages[r]&&(t.src=e.centralImages[r].url,t.alt=e.centralImages[r].label),this.hotspotLayer.render(e.hotspots,this.activeView,this.activeFilter)}}),this.carousel=new L(n,{onSelectHotspot:r=>{r.view&&r.view!==this.activeView&&this.viewToggle.onViewChange(r.view),this.hotspotLayer.markVisited(r.id),this.infoPanel.show(r),m.trackHotspotClick(e.moduleId,r.id,r.label,r.category)}}),this.viewToggle.render(e.centralImages,this.activeView),this.hotspotLayer.render(e.hotspots,this.activeView,this.activeFilter),this.carousel.render(e.hotspots);const o=this.container.querySelectorAll(".filter-btn");o.forEach(r=>{r.addEventListener("click",()=>{const h=r.getAttribute("data-filter");this.activeFilter=h,o.forEach(d=>d.classList.remove("active")),r.classList.add("active"),this.hotspotLayer.render(e.hotspots,this.activeView,this.activeFilter)})})}}class C extends g{constructor(e){super(e,"src/data/modul1-hotspots.json")}}class A extends g{constructor(e){super(e,"src/data/modul2-hotspots.json")}}class M extends g{constructor(e){super(e,"src/data/modul3-hotspots.json")}}class B extends g{constructor(e){super(e,"src/data/modul4a-hotspots.json")}}class P extends g{constructor(e){super(e,"src/data/modul4b-hotspots.json")}}class ${constructor(e){this.container=e,this.quizData=null,this.currentIndex=0,this.userAnswers=[],this.isSubmitted=!1}async loadQuestions(){try{const e=await fetch("src/data/evaluasi-questions.json");this.quizData=await e.json()}catch(e){console.error("[Evaluasi] Failed to load quiz JSON",e)}}async render(){this.quizData||await this.loadQuestions(),this.quizData&&(this.currentIndex=0,this.userAnswers=new Array(this.quizData.questions.length).fill(null),this.isSubmitted=!1,this.renderQuestionScreen(),m.trackModuleView("evaluasi","Ujian Evaluasi Modus Penyelundupan Narkotika"))}renderQuestionScreen(){const e=this.quizData.questions[this.currentIndex],t=this.quizData.questions.length,i=this.userAnswers[this.currentIndex],s=`
      <div style="width: 100%; height: 100%; overflow-y: auto; padding: 32px; display: flex; flex-direction: column; align-items: center; justify-content: center;">
        <div style="width: 100%; max-width: 780px; background: var(--bg-dark-800); border: 1px solid var(--surface-glass-border); border-radius: var(--radius-xl); padding: 32px; box-shadow: var(--shadow-lg);">
          
          <!-- Header Progress -->
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; border-bottom: 1px solid var(--surface-glass-border); padding-bottom: 16px;">
            <div>
              <span class="badge badge-gold">${e.category}</span>
              <span style="font-size: 0.85rem; color: var(--text-secondary); margin-left: 8px;">Soal ${this.currentIndex+1} dari ${t}</span>
            </div>
            <div style="font-size: 0.85rem; font-weight: 600; color: var(--accent-gold);">
              Batas Kelulusan: ${this.quizData.passingScorePercent}%
            </div>
          </div>

          <!-- Question Prompt -->
          <h3 style="font-size: 1.15rem; color: #FFF; line-height: 1.5; margin-bottom: 24px;">
            ${e.question}
          </h3>

          <!-- Options List -->
          <div style="display: flex; flex-direction: column; gap: 12px; margin-bottom: 32px;">
            ${e.options.map((a,n)=>{const o=i===n;return`
                <button class="btn btn-outline quiz-option-btn ${o?"active-gold":""}" 
                        data-index="${n}"
                        style="justify-content: flex-start; text-align: left; padding: 14px 18px; ${o?"border-color: var(--accent-gold); background: rgba(245,166,35,0.15);":""}">
                  <span style="width: 26px; height: 26px; border-radius: 50%; background: ${o?"var(--accent-gold)":"rgba(255,255,255,0.1)"}; color: ${o?"#000":"#FFF"}; font-weight: 700; font-size: 0.8rem; display: inline-flex; align-items: center; justify-content: center; flex-shrink: 0; margin-right: 10px;">
                    ${String.fromCharCode(65+n)}
                  </span>
                  <span style="font-size: 0.92rem;">${a}</span>
                </button>
              `}).join("")}
          </div>

          <!-- Navigation Footer -->
          <div style="display: flex; align-items: center; justify-content: space-between; border-top: 1px solid var(--surface-glass-border); padding-top: 20px;">
            <button id="prev-question-btn" class="btn btn-outline" ${this.currentIndex===0?'disabled style="opacity:0.4; cursor:not-allowed;"':""}>
              &larr; Sebelumnya
            </button>

            ${this.currentIndex<t-1?`
              <button id="next-question-btn" class="btn btn-gold">
                Berikutnya &rarr;
              </button>
            `:`
              <button id="submit-quiz-btn" class="btn btn-gold">
                Selesaikan Ujian ✅
              </button>
            `}
          </div>

        </div>
      </div>
    `;this.container.innerHTML=s,this.attachQuestionEvents()}attachQuestionEvents(){this.container.querySelectorAll(".quiz-option-btn").forEach(a=>{a.addEventListener("click",()=>{const n=parseInt(a.getAttribute("data-index"),10);this.userAnswers[this.currentIndex]=n,this.renderQuestionScreen()})});const t=this.container.querySelector("#prev-question-btn");t&&this.currentIndex>0&&t.addEventListener("click",()=>{this.currentIndex--,this.renderQuestionScreen()});const i=this.container.querySelector("#next-question-btn");i&&i.addEventListener("click",()=>{if(this.userAnswers[this.currentIndex]===null){alert("Pilih salah satu jawaban sebelum melanjutkan!");return}this.currentIndex++,this.renderQuestionScreen()});const s=this.container.querySelector("#submit-quiz-btn");s&&s.addEventListener("click",()=>{if(this.userAnswers[this.currentIndex]===null){alert("Pilih salah satu jawaban sebelum menyelesaikan ujian!");return}this.calculateResult()})}calculateResult(){let e=0;const t=this.quizData.questions;t.forEach((n,o)=>{this.userAnswers[o]===n.correctIndex&&e++});const i=t.length,s=Math.round(e/i*100),a=s>=this.quizData.passingScorePercent;p.setCompleted(s),m.trackQuizCompleted(s,a,i),this.renderResultScreen(s,a,e,i)}renderResultScreen(e,t,i,s){const a=`
      <div style="width: 100%; height: 100%; overflow-y: auto; padding: 32px; display: flex; flex-direction: column; align-items: center; justify-content: center;">
        <div style="width: 100%; max-width: 650px; background: var(--bg-dark-800); border: 1px solid var(--surface-glass-border); border-radius: var(--radius-xl); padding: 40px; text-align: center; box-shadow: var(--shadow-lg);">
          
          <div style="font-size: 4rem; margin-bottom: 12px;">
            ${t?"🏆":"⚠️"}
          </div>

          <h2 style="font-size: 1.8rem; color: #FFF; margin-bottom: 8px;">
            ${t?"Selamat! Anda Lulus Evaluasi":"Belum Mencapai Batas Kelulusan"}
          </h2>

          <div style="font-size: 3rem; font-weight: 800; color: ${t?"#34C759":"#FF3B30"}; margin: 16px 0;">
            ${e}%
          </div>

          <p style="font-size: 0.95rem; color: var(--text-secondary); margin-bottom: 24px;">
            Anda menjawab benar <strong>${i}</strong> dari <strong>${s}</strong> soal scenario.<br>
            Batas kelulusan minimum: ${this.quizData.passingScorePercent}%. Status kelulusan SCORM telah dicatat ke KLC.
          </p>

          <div style="display: flex; gap: 16px; justify-content: center;">
            <button id="retake-quiz-btn" class="btn btn-outline">
              🔄 Ulangi Ujian
            </button>
            <a href="#/beranda" class="btn btn-gold">
              🏠 Kembali ke Beranda
            </a>
          </div>

        </div>
      </div>
    `;this.container.innerHTML=a;const n=this.container.querySelector("#retake-quiz-btn");n&&n.addEventListener("click",()=>this.render())}}class z{constructor(e){this.container=e,this.routes={beranda:b,modul1:C,modul2:A,modul3:M,modul4a:B,modul4b:P,evaluasi:$},this.currentViewInstance=null}init(){window.addEventListener("hashchange",()=>this.handleRoute());const e=p.getBookmark();e&&this.routes[e]&&!window.location.hash?window.location.hash=`#/${e}`:window.location.hash||(window.location.hash="#/beranda"),this.handleRoute()}async handleRoute(){const t=(window.location.hash.replace(/^#\//,"")||"beranda").toLowerCase(),i=this.routes[t]||b;this.updateSidebarActive(t),p.setBookmark(t),this.currentViewInstance=new i(this.container),await this.currentViewInstance.render(),this.container.scrollTop=0}updateSidebarActive(e){document.querySelectorAll("#sidebar .nav-item").forEach(a=>{a.getAttribute("data-route")===e?(a.classList.add("active"),a.style.color="var(--accent-gold)",a.style.background="var(--bg-dark-600)"):(a.classList.remove("active"),a.style.color="var(--text-secondary)",a.style.background="transparent")});const i=document.getElementById("page-title"),s={beranda:"Beranda & Panduan Inspeksi",modul1:"Modul 1: Penyelundupan Melalui Tubuh Kurir",modul2:"Modul 2: Penyelundupan Melalui Barang Bawaan",modul3:"Modul 3: Penyelundupan Melalui Barang Kiriman",modul4a:"Modul 4A: Penyelundupan Melalui Kendaraan Darat (SUV)",modul4b:"Modul 4B: Penyelundupan Melalui Kapal Laut Cargo",evaluasi:"Ujian Evaluasi Modus Penyelundupan Narkotika"};i&&(i.textContent=s[e]||"Modul Inspeksi DJBC")}}class F{constructor(){this.container=document.getElementById("modal-root")}render(){const e=c.getConfig(),t=`
      <div id="lrs-modal-backdrop" class="modal-backdrop open">
        <div class="modal-card animate-slide-up">
          <div class="modal-header">
            <div style="display: flex; align-items: center; gap: 10px;">
              <span style="font-size: 1.3rem;">⚙️</span>
              <h3 style="margin: 0; font-size: 1.1rem; color: #FFF;">Pengaturan LRS / xAPI Analytics</h3>
            </div>
            <button id="close-lrs-modal-btn" class="btn-icon" style="width:32px; height:32px;">✕</button>
          </div>

          <form id="lrs-config-form">
            <p style="font-size: 0.82rem; color: var(--text-secondary); margin-bottom: 16px;">
              Masukkan detail Learning Record Store (LRS) untuk mengirim analytics interaksi peserta secara real-time via xAPI.
            </p>

            <div class="form-group">
              <label for="lrs-endpoint">LRS Endpoint URL</label>
              <input type="url" id="lrs-endpoint" class="form-control" 
                     placeholder="https://lrs.kemenkeu.go.id/xAPI/" 
                     value="${e.endpoint||""}" required>
            </div>

            <div class="form-group">
              <label for="lrs-username">LRS Basic Auth Username / Key</label>
              <input type="text" id="lrs-username" class="form-control" 
                     placeholder="Contoh: djbc_lms_key" 
                     value="${e.username||""}" required>
            </div>

            <div class="form-group">
              <label for="lrs-password">LRS Basic Auth Password / Secret</label>
              <input type="password" id="lrs-password" class="form-control" 
                     placeholder="••••••••••••••••" 
                     value="${e.password||""}" required>
            </div>

            <div class="form-group" style="flex-direction: row; align-items: center; gap: 10px; margin-top: 10px;">
              <input type="checkbox" id="lrs-enabled" ${e.enabled?"checked":""}>
              <label for="lrs-enabled" style="margin: 0; cursor: pointer;">Aktifkan Pengiriman xAPI Statement</label>
            </div>

            <div id="lrs-test-status" style="margin: 12px 0; font-size: 0.82rem; display: none; padding: 8px 12px; border-radius: 6px;"></div>

            <div style="display: flex; align-items: center; justify-content: flex-end; gap: 12px; margin-top: 20px;">
              <button type="button" id="test-lrs-btn" class="btn btn-outline">Uji Koneksi</button>
              <button type="submit" class="btn btn-gold">Simpan Pengaturan</button>
            </div>
          </form>
        </div>
      </div>
    `;this.container.innerHTML=t,this.attachEvents()}attachEvents(){const e=document.getElementById("lrs-modal-backdrop"),t=document.getElementById("close-lrs-modal-btn"),i=document.getElementById("lrs-config-form"),s=document.getElementById("test-lrs-btn"),a=document.getElementById("lrs-test-status"),n=()=>{e.classList.remove("open"),setTimeout(()=>{this.container.innerHTML=""},300)};t.addEventListener("click",n),e.addEventListener("click",o=>{o.target===e&&n()}),s.addEventListener("click",async()=>{const o=document.getElementById("lrs-endpoint").value,r=document.getElementById("lrs-username").value,h=document.getElementById("lrs-password").value;a.style.display="block",a.style.background="rgba(255, 149, 0, 0.2)",a.style.color="#FFB340",a.innerText="Menguji koneksi ke LRS...";const d=await c.testConnection(o,r,h);d.success?(a.style.background="rgba(52, 199, 89, 0.2)",a.style.color="#5CD97D",a.innerText=d.message):(a.style.background="rgba(255, 59, 48, 0.2)",a.style.color="#FF6B6B",a.innerText=d.message)}),i.addEventListener("submit",o=>{o.preventDefault();const r=document.getElementById("lrs-endpoint").value,h=document.getElementById("lrs-username").value,d=document.getElementById("lrs-password").value,v=document.getElementById("lrs-enabled").checked;c.saveConfig(r,h,d,v);const f=document.getElementById("lrs-status-dot");f&&(f.style.background=v?"#34C759":"#64748B"),n()})}}class V{static async init(){console.log("[App] Initializing Interactive Narcotics Concealment Inspection Simulator..."),p.init(),await u.init();const e=document.getElementById("lrs-config-btn"),t=document.getElementById("lrs-status-dot");t&&(t.style.background=c.isConfigured()?"#34C759":"#64748B"),e&&e.addEventListener("click",()=>{new F().render()});const i=document.getElementById("sidebar"),s=document.getElementById("sidebar-toggle-btn");s&&i&&s.addEventListener("click",()=>{i.classList.toggle("collapsed")});const a=document.getElementById("content-area");new z(a).init(),window.addEventListener("beforeunload",()=>{p.terminate()})}}document.addEventListener("DOMContentLoaded",()=>{V.init()});
//# sourceMappingURL=index-6ypMmJyL.js.map
