(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const i of document.querySelectorAll('link[rel="modulepreload"]'))n(i);new MutationObserver(i=>{for(const s of i)if(s.type==="childList")for(const a of s.addedNodes)a.tagName==="LINK"&&a.rel==="modulepreload"&&n(a)}).observe(document,{childList:!0,subtree:!0});function t(i){const s={};return i.integrity&&(s.integrity=i.integrity),i.referrerPolicy&&(s.referrerPolicy=i.referrerPolicy),i.crossOrigin==="use-credentials"?s.credentials="include":i.crossOrigin==="anonymous"?s.credentials="omit":s.credentials="same-origin",s}function n(i){if(i.ep)return;i.ep=!0;const s=t(i);fetch(i.href,s)}})();class y{constructor(){this.api=null,this.version=null,this.isInitialized=!1,this.learnerName="",this.learnerId=""}findAPI(e){let t=0,n=e;for(;n&&t<10;){if(n.API_1484_11)return this.version="2004",n.API_1484_11;if(n.API)return this.version="1.2",n.API;if(n.parent&&n.parent!==n)n=n.parent;else if(n.opener)n=n.opener;else break;t++}return null}init(){if(this.api=this.findAPI(window),!this.api)return console.warn("[SCORM] No SCORM API found. Running in standalone LMS simulation mode."),!1;try{let e=!1;this.version==="2004"?e=this.api.Initialize(""):this.version==="1.2"&&(e=this.api.LMSInitialize("")),this.isInitialized=e==="true"||e===!0,this.isInitialized?(this.fetchLearnerInfo(),console.log(`[SCORM] Successfully initialized SCORM ${this.version} API.`)):console.error("[SCORM] API Initialize failed.")}catch(e){console.error("[SCORM] Exception during initialization:",e)}return this.isInitialized}fetchLearnerInfo(){this.isInitialized&&(this.version==="2004"?(this.learnerName=this.getValue("cmi.learner_name"),this.learnerId=this.getValue("cmi.learner_id")):(this.learnerName=this.getValue("cmi.core.student_name"),this.learnerId=this.getValue("cmi.core.student_id")))}getValue(e){if(!this.isInitialized||!this.api)return"";try{return this.version==="2004"?this.api.GetValue(e):this.api.LMSGetValue(e)}catch(t){return console.error(`[SCORM] GetValue failed for ${e}`,t),""}}setValue(e,t){if(!this.isInitialized||!this.api)return!1;try{let n;return this.version==="2004"?n=this.api.SetValue(e,String(t)):n=this.api.LMSSetValue(e,String(t)),n==="true"||n===!0}catch(n){return console.error(`[SCORM] SetValue failed for ${e}`,n),!1}}commit(){if(!this.isInitialized||!this.api)return!1;try{return this.version==="2004"?this.api.Commit("")==="true":this.api.LMSCommit("")==="true"}catch(e){return console.error("[SCORM] Commit failed",e),!1}}terminate(){if(!this.isInitialized||!this.api)return!1;try{let e;return this.version==="2004"?e=this.api.Terminate(""):e=this.api.LMSFinish(""),this.isInitialized=!1,e==="true"||e===!0}catch(e){return console.error("[SCORM] Terminate failed",e),!1}}setBookmark(e){this.version==="2004"?this.setValue("cmi.location",e):this.setValue("cmi.core.lesson_location",e),this.commit()}getBookmark(){return this.version==="2004"?this.getValue("cmi.location"):this.getValue("cmi.core.lesson_location")}setCompleted(e=100){this.version==="2004"?(this.setValue("cmi.completion_status","completed"),this.setValue("cmi.success_status",e>=70?"passed":"failed"),this.setValue("cmi.score.scaled",(e/100).toFixed(2)),this.setValue("cmi.score.raw",e),this.setValue("cmi.score.min","0"),this.setValue("cmi.score.max","100")):(this.setValue("cmi.core.lesson_status",e>=70?"passed":"completed"),this.setValue("cmi.core.score.raw",e)),this.commit()}}const m=new y;class k{constructor(){this._profile=null,this._isLoaded=!1,this._authMethod="UNINITIALIZED",this.DEFAULT_PROFILE={username:"pegawai_djbc",nip:"199001012015011001",name:"Pegawai DJBC (Simulasi)",email:"pegawai.djbc@kemenkeu.go.id",role:"PEGAWAI",avatarUrl:"",unit:"Direktorat Jenderal Bea dan Cukai",organisasi:"Kementerian Keuangan RI"}}async init(){if(this._isLoaded)return this._profile;try{const i=await fetch("/office/api/auth/session",{credentials:"include"});if(i.ok){const s=await i.json();if(s&&(s.user||s.username||s.name)){const a=s.user||s;return this._profile={username:a.username||a.nip||a.email||"pegawai_klc",nip:a.nip||a.username||"",name:a.name||a.nama||a.displayName||"Pegawai DJBC",email:a.email||`${a.username||"pegawai"}@kemenkeu.go.id`,role:(a.role||a.jabatan||"PEGAWAI").toUpperCase(),avatarUrl:a.avatarUrl||a.avatar||a.foto||"",unit:a.unit||a.unitKerja||"Direktorat Jenderal Bea dan Cukai",organisasi:a.organisasi||"Kementerian Keuangan RI"},this._authMethod="SESSION_API",this._isLoaded=!0,this.updateDOM(),this._profile}}}catch{}const e=new URLSearchParams(window.location.search);if(e.has("username")||e.has("nip"))return this._profile={username:e.get("username")||e.get("nip"),nip:e.get("nip")||e.get("username"),name:e.get("name")||e.get("username")||"Pegawai DJBC",email:e.get("email")||"pegawai@kemenkeu.go.id",role:(e.get("role")||"PEGAWAI").toUpperCase(),avatarUrl:e.get("avatar")||"",unit:"Direktorat Jenderal Bea dan Cukai",organisasi:"Kementerian Keuangan RI"},this._authMethod="URL_PARAMS",this._isLoaded=!0,this.updateDOM(),this._profile;const t=window.scormInstance?window.scormInstance.learnerName:"",n=window.scormInstance?window.scormInstance.learnerId:"";return t||n?(this._profile={username:n||"scorm_user",nip:n||"",name:t||"Pegawai SCORM",email:`${n||"pegawai"}@kemenkeu.go.id`,role:"PEGAWAI",avatarUrl:"",unit:"Direktorat Jenderal Bea dan Cukai",organisasi:"Kementerian Keuangan RI"},this._authMethod="SCORM_API",this._isLoaded=!0,this.updateDOM(),this._profile):(this._profile={...this.DEFAULT_PROFILE},this._authMethod="DEFAULT_FALLBACK",this._isLoaded=!0,this.updateDOM(),this._profile)}getProfile(){return this._profile||this.DEFAULT_PROFILE}getAuthMethod(){return this._authMethod}getActorForXAPI(){const e=this.getProfile();return{objectType:"Agent",name:e.name,mbox:`mailto:${e.email}`,account:{homePage:"https://klc2.kemenkeu.go.id",name:e.username||e.nip}}}updateDOM(){const e=this.getProfile(),t=document.getElementById("user-display-name"),n=document.getElementById("user-display-role"),i=document.getElementById("user-avatar-img"),s=document.getElementById("user-avatar-placeholder"),a=document.getElementById("user-avatar-initials");if(t&&(t.textContent=e.name),n&&(n.textContent=`${e.role} — ${e.unit}`),e.avatarUrl&&i)i.src=e.avatarUrl,i.style.display="block",s&&(s.style.display="none"),a&&(a.style.display="none");else if(a){i&&(i.style.display="none"),s&&(s.style.display="none"),a.style.display="block";const o=e.name.split(" ").map(d=>d[0]).join("").substring(0,2).toUpperCase();a.textContent=o||"BC"}}}const g=new k;class x{constructor(){this.STORAGE_KEY="djbc_lrs_config",this.config=this.loadConfig()}loadConfig(){try{const e=localStorage.getItem(this.STORAGE_KEY);if(e)return JSON.parse(e)}catch(e){console.error("[LRSConfig] Failed to load config",e)}return{endpoint:"",username:"",password:"",enabled:!1}}saveConfig(e,t,n,i=!0){let s=(e||"").trim();s&&!s.endsWith("/")&&(s+="/"),this.config={endpoint:s,username:(t||"").trim(),password:(n||"").trim(),enabled:!!i};try{localStorage.setItem(this.STORAGE_KEY,JSON.stringify(this.config))}catch(a){console.error("[LRSConfig] Failed to save config",a)}return this.config}getConfig(){return{...this.config}}isConfigured(){return!!(this.config.enabled&&this.config.endpoint&&this.config.username)}getAuthHeader(){return!this.config.username||!this.config.password?"":"Basic "+btoa(`${this.config.username}:${this.config.password}`)}async testConnection(e,t,n){let i=(e||"").trim();i.endsWith("/")||(i+="/"),i+="about";const s={"X-Experience-API-Version":"1.0.3"};t&&n&&(s.Authorization="Basic "+btoa(`${t}:${n}`));try{const a=await fetch(i,{method:"GET",headers:s});return a.ok?{success:!0,message:"Koneksi ke LRS berhasil!",version:(await a.json().catch(()=>({}))).version||["1.0.3"]}:{success:!1,message:`LRS merespon HTTP ${a.status} (${a.statusText})`}}catch(a){return{success:!1,message:`Gagal menghubungi LRS: ${a.message}`}}}}const u=new x;class w{constructor(){this.BASE_URL=window.location.origin+window.location.pathname}getVerbs(){return{launched:{id:"http://adlnet.gov/expapi/verbs/launched",display:{"id-ID":"memulai"}},initialized:{id:"http://adlnet.gov/expapi/verbs/initialized",display:{"id-ID":"menginisialisasi"}},interacted:{id:"http://adlnet.gov/expapi/verbs/interacted",display:{"id-ID":"berinteraksi"}},viewed:{id:"http://id.tincanapi.com/verb/viewed",display:{"id-ID":"melihat"}},answered:{id:"http://adlnet.gov/expapi/verbs/answered",display:{"id-ID":"menjawab"}},completed:{id:"http://adlnet.gov/expapi/verbs/completed",display:{"id-ID":"menyelesaikan"}},passed:{id:"http://adlnet.gov/expapi/verbs/passed",display:{"id-ID":"lulus"}},failed:{id:"http://adlnet.gov/expapi/verbs/failed",display:{"id-ID":"gagal"}}}}buildStatement({verb:e,activityId:t,activityName:n,activityDesc:i,result:s,contextExtensions:a}){const d={actor:g.getActorForXAPI(),verb:e,object:{objectType:"Activity",id:`${this.BASE_URL}#/${t}`,definition:{name:{"id-ID":n,"en-US":n},description:{"id-ID":i||n}}},timestamp:new Date().toISOString(),context:{registration:this.getRegistrationId(),contextActivities:{parent:[{id:`${this.BASE_URL}#/module-inspection-suite`,definition:{name:{"id-ID":"Modul Interaktif Penyelundupan Narkotika DJBC"}}}]},extensions:{"http://klc2.kemenkeu.go.id/xapi/extensions/unit":g.getProfile().unit,"http://klc2.kemenkeu.go.id/xapi/extensions/role":g.getProfile().role,...a||{}}}};return s&&(d.result=s),d}getRegistrationId(){let e=sessionStorage.getItem("xapi_registration_id");return e||(e="reg-"+Math.random().toString(36).substring(2,11)+"-"+Date.now(),sessionStorage.setItem("xapi_registration_id",e)),e}async sendStatement(e){if(console.log("[xAPI Statement Generated]",e),!u.isConfigured())return{sent:!1,reason:"LRS not configured or disabled"};const n=u.getConfig().endpoint+"statements";try{const i=await fetch(n,{method:"POST",headers:{"Content-Type":"application/json","X-Experience-API-Version":"1.0.3",Authorization:u.getAuthHeader()},body:JSON.stringify(e)});return i.ok?(console.log("[xAPI Statement Successfully Sent to LRS]"),{sent:!0}):(console.warn(`[xAPI Send Failed] HTTP ${i.status}`,await i.text().catch(()=>"")),{sent:!1,reason:`HTTP ${i.status}`})}catch(i){return console.error("[xAPI Exception]",i),{sent:!1,reason:i.message}}}trackModuleView(e,t){const n=this.getVerbs(),i=this.buildStatement({verb:n.launched,activityId:e,activityName:`Modul Inspeksi: ${t}`,activityDesc:`Peserta membuka halaman modul ${t}`});this.sendStatement(i)}trackHotspotClick(e,t,n,i){const s=this.getVerbs(),a=this.buildStatement({verb:s.interacted,activityId:`${e}/hotspot/${t}`,activityName:`Hotspot: ${n}`,activityDesc:`Peserta mengeklik hotspot ${n} pada modul ${e}`,contextExtensions:{"http://klc2.kemenkeu.go.id/xapi/extensions/category":i,"http://klc2.kemenkeu.go.id/xapi/extensions/module":e}});this.sendStatement(a)}trackQuizCompleted(e,t,n){const i=this.getVerbs(),s=t?i.passed:i.failed,a=this.buildStatement({verb:s,activityId:"evaluasi-narkotika-djbc",activityName:"Ujian Evaluasi Modus Penyelundupan Narkotika",result:{score:{scaled:(e/100).toFixed(2),raw:e,min:0,max:100},success:t,completion:!0}});this.sendStatement(a)}}const h=new w;class b{constructor(e){this.container=e}async render(){const e=g.getProfile(),t=`
      <div style="width: 100%; height: 100%; overflow-y: auto; padding: 32px; display: flex; flex-direction: column; gap: 32px; max-width: 1280px; margin: 0 auto;">
        
        <!-- Hero Section -->
        <div style="background: linear-gradient(135deg, rgba(18, 34, 56, 0.9) 0%, rgba(10, 22, 40, 0.95) 100%); border: 1px solid var(--surface-glass-border); border-radius: var(--radius-xl); padding: 36px; display: flex; align-items: center; justify-content: space-between; box-shadow: var(--shadow-lg); position: relative; overflow: hidden;">
          <div style="position: absolute; right: -40px; top: -40px; width: 300px; height: 300px; background: var(--accent-gold-glow); filter: blur(80px); border-radius: 50%; pointer-events: none;"></div>

          <div style="max-width: 720px; z-index: 1;">
            <div class="badge badge-gold" style="margin-bottom: 12px; font-size: 0.8rem;">E-LEARNING INTERAKTIF DJBC 2026</div>
            <h1 style="font-size: 2.2rem; margin-bottom: 12px; color: #FFF; line-height: 1.2;">
              Inspeksi Modus Penyelundupan Narkotika
            </h1>
            <p style="font-size: 1rem; color: var(--text-secondary); line-height: 1.6; margin-bottom: 24px;">
              Selamat datang, <strong style="color: var(--accent-gold);">${e.name}</strong> (${e.nip||e.username}). Modul ini dirancang khusus untuk meningkatkan kapabilitas teknis pegawai Direktorat Jenderal Bea dan Cukai dalam mendeteksi dan menginspeksi titik-titik penyembunyian Narkotika pada 4 moda pemeriksaan utama.
            </p>
            <div style="display: flex; gap: 16px;">
              <a href="#/modul1" class="btn btn-gold">
                🚀 Mulai Pembelajaran (Modul 1)
              </a>
              <a href="#/evaluasi" class="btn btn-outline">
                📝 Ujian Evaluasi
              </a>
            </div>
          </div>

          <div style="display: flex; flex-direction: column; gap: 12px; z-index: 1; min-width: 220px; background: rgba(0,0,0,0.3); padding: 20px; border-radius: var(--radius-lg); border: 1px solid var(--surface-glass-border);">
            <div style="font-size: 0.78rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">STATUS ANALYTICS xAPI</div>
            <div style="display: flex; align-items: center; gap: 10px;">
              <span style="width: 10px; height: 10px; border-radius: 50%; background: #34C759;"></span>
              <span style="font-size: 0.85rem; font-weight: 600; color: #FFF;">KLC Session Connected</span>
            </div>
            <div style="font-size: 0.75rem; color: var(--text-secondary);">
              Metode Auth: <code style="color: var(--accent-gold);">${g.getAuthMethod()}</code>
            </div>
          </div>
        </div>

        <!-- 4 Key Modules Cards -->
        <div>
          <h2 style="font-size: 1.3rem; color: #FFF; margin-bottom: 16px;">Kategori Modul Inspeksi Interaktif</h2>
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px;">
            
            <!-- Modul 1 Card -->
            <a href="#/modul1" style="text-decoration: none; color: inherit;">
              <div class="card-hover" style="background: var(--bg-dark-800); border: 1px solid var(--surface-glass-border); border-radius: var(--radius-lg); padding: 24px; display: flex; flex-direction: column; gap: 12px; transition: transform 0.2s, border-color 0.2s;">
                <div style="font-size: 2.2rem;">👤</div>
                <h3 style="font-size: 1.1rem; color: #FFF; margin: 0;">1. Tubuh Kurir</h3>
                <p style="font-size: 0.85rem; color: var(--text-secondary); margin: 0; line-height: 1.5;">
                  Inspeksi anatomi & X-Ray tubuh kurir: Body Packing (swallowing pellets), Body Strapping, dan Insertion.
                </p>
                <div style="font-size: 0.8rem; font-weight: 600; color: var(--accent-gold); margin-top: auto;">Buka Modul 1 &rarr;</div>
              </div>
            </a>

            <!-- Modul 2 Card -->
            <a href="#/modul2" style="text-decoration: none; color: inherit;">
              <div class="card-hover" style="background: var(--bg-dark-800); border: 1px solid var(--surface-glass-border); border-radius: var(--radius-lg); padding: 24px; display: flex; flex-direction: column; gap: 12px; transition: transform 0.2s, border-color 0.2s;">
                <div style="font-size: 2.2rem;">🧳</div>
                <h3 style="font-size: 1.1rem; color: #FFF; margin: 0;">2. Barang Bawaan</h3>
                <p style="font-size: 0.85rem; color: var(--text-secondary); margin: 0; line-height: 1.5;">
                  Pemeriksaan koper bagasi penumpang: False Bottom, Dinding Ganda, Rangka Trolley, & Lipatan Jahitan.
                </p>
                <div style="font-size: 0.8rem; font-weight: 600; color: var(--accent-gold); margin-top: auto;">Buka Modul 2 &rarr;</div>
              </div>
            </a>

            <!-- Modul 3 Card -->
            <a href="#/modul3" style="text-decoration: none; color: inherit;">
              <div class="card-hover" style="background: var(--bg-dark-800); border: 1px solid var(--surface-glass-border); border-radius: var(--radius-lg); padding: 24px; display: flex; flex-direction: column; gap: 12px; transition: transform 0.2s, border-color 0.2s;">
                <div style="font-size: 2.2rem;">📦</div>
                <h3 style="font-size: 1.1rem; color: #FFF; margin: 0;">3. Barang Kiriman</h3>
                <p style="font-size: 0.85rem; color: var(--text-secondary); margin: 0; line-height: 1.5;">
                  Inspeksi kargo Pos & PJT: Kaleng Makanan Palsu (Liquid Meth), Kardus Corrugated, & Elektronik.
                </p>
                <div style="font-size: 0.8rem; font-weight: 600; color: var(--accent-gold); margin-top: auto;">Buka Modul 3 &rarr;</div>
              </div>
            </a>

            <!-- Modul 4A & 4B Card -->
            <a href="#/modul4a" style="text-decoration: none; color: inherit;">
              <div class="card-hover" style="background: var(--bg-dark-800); border: 1px solid var(--surface-glass-border); border-radius: var(--radius-lg); padding: 24px; display: flex; flex-direction: column; gap: 12px; transition: transform 0.2s, border-color 0.2s;">
                <div style="font-size: 2.2rem;">🚗 🚢</div>
                <h3 style="font-size: 1.1rem; color: #FFF; margin: 0;">4. Sarana Pengangkut</h3>
                <p style="font-size: 0.85rem; color: var(--text-secondary); margin: 0; line-height: 1.5;">
                  Pemeriksaan Kompartemen Pintu Mobil, Tangki Bahan Bakar Dinding Ganda, Kontainer Reefer, & Kapal Laut.
                </p>
                <div style="font-size: 0.8rem; font-weight: 600; color: var(--accent-gold); margin-top: auto;">Buka Modul 4 &rarr;</div>
              </div>
            </a>

          </div>
        </div>

        <!-- Instructions Section -->
        <div style="background: rgba(255,255,255,0.02); border: 1px solid var(--surface-glass-border); border-radius: var(--radius-lg); padding: 24px;">
          <h3 style="font-size: 1.1rem; color: var(--accent-gold); margin-bottom: 12px;">📌 Panduan Navigasi & Fitur Modul</h3>
          <ul style="color: var(--text-secondary); font-size: 0.9rem; line-height: 1.8; margin-left: 20px;">
            <li>Gunakan tombol <strong>X-Ray View / Cutaway View</strong> untuk beralih antara tampilan fisik normal dan tampilan sinar-X / penampang irisan.</li>
            <li>Klik atau hover <strong>Hotspot Berpendar (Pulse Marker)</strong> di layar untuk melihat gambar visual realistis modus, indikator risiko, dan SOP tindakan Bea Cukai.</li>
            <li>Gunakan <strong>Bottom Thumbnail Carousel</strong> untuk melompat langsung ke titik penyembunyian tertentu.</li>
            <li>Selesaikan seluruh modul interaktif kemudian ikuti <strong>Ujian Evaluasi</strong> untuk mendapatkan kelulusan SCORM & xAPI.</li>
          </ul>
        </div>

      </div>
    `;this.container.innerHTML=t,h.trackModuleView("beranda","Beranda & Panduan Inspeksi")}}class I{constructor(e,{onHotspotClick:t}){this.container=e,this.onHotspotClick=t,this.visitedSet=new Set,this.activeFilter="all",this.activeView="front",this.hotspots=[]}render(e,t="front",n="all",i=0){this.hotspots=e,this.activeView=t,this.activeFilter=n;const s=e.filter(a=>{const o=a.view?a.view===t:!0,d=n==="all"||a.category===n;let r=!0;return a.angleMin!==void 0&&a.angleMax!==void 0&&(a.angleMin<=a.angleMax?r=i>=a.angleMin&&i<=a.angleMax:r=i>=a.angleMin||i<=a.angleMax),o&&d&&r});this.container.innerHTML=s.map(a=>`
        <div class="hotspot-marker ${this.visitedSet.has(a.id)?"visited":""} animate-fade-in" 
             data-id="${a.id}" 
             style="left: ${a.position.x}%; top: ${a.position.y}%;">
          <div class="hotspot-pulse"></div>
          <div class="hotspot-inner"></div>
          <div class="hotspot-tooltip">${a.label}</div>
        </div>
      `).join(""),this.attachEvents()}attachEvents(){this.container.querySelectorAll(".hotspot-marker").forEach(t=>{t.addEventListener("click",n=>{n.stopPropagation();const i=t.getAttribute("data-id");this.visitedSet.add(i),t.classList.add("visited");const s=this.hotspots.find(a=>a.id===i);s&&this.onHotspotClick&&this.onHotspotClick(s)})})}markVisited(e){this.visitedSet.add(e);const t=this.container.querySelector(`.hotspot-marker[data-id="${e}"]`);t&&t.classList.add("visited")}getVisitedCount(){return this.visitedSet.size}}class A{constructor(e){this.drawer=e,this.currentData=null}show(e){this.currentData=e;const t=e.badgeType?`badge-${e.badgeType}`:"badge-danger",n=(e.riskIndicators||[]).map(o=>`
      <div class="risk-item">
        <span>⚠️</span>
        <div>${o}</div>
      </div>
    `).join(""),i=(e.inspectionActions||[]).map(o=>`
      <div class="action-item">
        <span>🔍</span>
        <div>${o}</div>
      </div>
    `).join(""),s=`
      <div class="drawer-header">
        <div>
          <span class="badge ${t}" style="margin-bottom: 8px;">${e.badge||"MODUS PENYELUNDUPAN"}</span>
          <h3 style="margin: 0; font-size: 1.15rem; color: #FFF; line-height: 1.3;">${e.label}</h3>
        </div>
        <button id="close-info-drawer-btn" class="btn-icon" style="width:32px; height:32px; flex-shrink: 0;">✕</button>
      </div>

      <div class="drawer-body">
        <!-- Hotspot Main Realistic Image -->
        <div class="drawer-image-container">
          <img src="${e.mainImage}" alt="${e.label}" 
               onerror="this.onerror=null; this.src='assets/images/central/m1_body_front_xray.png';">
          <div style="position: absolute; bottom: 8px; right: 8px; background: rgba(0,0,0,0.7); padding: 2px 8px; border-radius: 4px; font-size: 0.68rem; color: #FFF;">
            Visual Modus Realistis
          </div>
        </div>

        <!-- Deskripsi Modus -->
        <div>
          <h4 style="font-size: 0.9rem; color: var(--accent-gold); margin-bottom: 6px;">Deskripsi Modus Penyelundupan</h4>
          <p style="font-size: 0.85rem; color: var(--text-primary); line-height: 1.6;">${e.description}</p>
        </div>

        <!-- Indikator Resiko / Anomali -->
        <div>
          <h4 style="font-size: 0.9rem; color: #FF9500; margin-bottom: 6px;">Indikator Risiko & Anomali (Red Flags)</h4>
          <div class="risk-list">
            ${n}
          </div>
        </div>

        <!-- Tindakan Inspeksi DJBC -->
        <div>
          <h4 style="font-size: 0.9rem; color: var(--accent-cyan); margin-bottom: 6px;">SOP Tindakan Inspeksi Bea Cukai</h4>
          <div class="action-list">
            ${i}
          </div>
        </div>
      </div>
    `;this.drawer.innerHTML=s,this.drawer.classList.add("open");const a=this.drawer.querySelector("#close-info-drawer-btn");a&&a.addEventListener("click",()=>this.hide())}hide(){this.drawer.classList.remove("open")}}class S{constructor(e,{onViewChange:t}){this.container=e,this.onViewChange=t,this.currentViewKey=""}render(e,t){this.currentViewKey=t;const n=Object.keys(e||{});if(n.length<=1){this.container.innerHTML="";return}const i=`
      <div class="view-mode-toggle">
        ${n.map(s=>{const a=e[s];return`
            <button class="view-mode-btn ${s===t?"active":""}" data-key="${s}">
              ${a.label||s.toUpperCase()}
            </button>
          `}).join("")}
      </div>
    `;this.container.innerHTML=i,this.attachEvents()}attachEvents(){const e=this.container.querySelectorAll(".view-mode-btn");e.forEach(t=>{t.addEventListener("click",()=>{const n=t.getAttribute("data-key");n&&n!==this.currentViewKey&&(this.currentViewKey=n,e.forEach(i=>i.classList.remove("active")),t.classList.add("active"),this.onViewChange&&this.onViewChange(n))})})}}class E{constructor(e,{onSelectHotspot:t}){this.container=e,this.onSelectHotspot=t,this.activeId=null}render(e,t=null){if(this.activeId=t,!e||e.length===0){this.container.innerHTML="";return}const n=`
      <div class="bottom-carousel-bar">
        <div style="font-size: 0.75rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase; padding-right: 8px; white-space: nowrap;">
          DAFTAR HOTSPOT:
        </div>
        ${e.map(i=>`
            <div class="carousel-thumb ${i.id===t?"active":""}" data-id="${i.id}">
              <img src="${i.mainImage}" alt="${i.label}" onerror="this.onerror=null; this.src='assets/images/central/m1_body_front_xray.png';">
              <div class="carousel-thumb-title">${i.label}</div>
            </div>
          `).join("")}
      </div>
    `;this.container.innerHTML=n,this.attachEvents(e)}attachEvents(e){const t=this.container.querySelectorAll(".carousel-thumb");t.forEach(n=>{n.addEventListener("click",()=>{const i=n.getAttribute("data-id"),s=e.find(a=>a.id===i);s&&this.onSelectHotspot&&(t.forEach(a=>a.classList.remove("active")),n.classList.add("active"),this.onSelectHotspot(s))})})}}class L{constructor(e,{onAngleChange:t}){this.container=e,this.onAngleChange=t,this.currentAngle=0,this.isDragging=!1,this.startX=0,this.startAngle=0}render(e=0){this.currentAngle=e;const t=`
      <div class="rotation-control-bar">
        <div class="angle-display">
          <span class="compass-icon">🧭</span>
          <span class="angle-text">${this.currentAngle}°</span>
          <span class="angle-label">${this.getAngleLabel(this.currentAngle)}</span>
        </div>

        <div class="angle-slider-wrapper">
          <input type="range" id="angle-range-slider" min="0" max="359" value="${this.currentAngle}" step="1" class="angle-range-slider">
        </div>

        <div class="angle-quick-btns">
          <button class="angle-btn ${this.isAngleActive(0)?"active":""}" data-angle="0">0° Depan</button>
          <button class="angle-btn ${this.isAngleActive(90)?"active":""}" data-angle="90">90° Kanan</button>
          <button class="angle-btn ${this.isAngleActive(180)?"active":""}" data-angle="180">180° Belakang</button>
          <button class="angle-btn ${this.isAngleActive(270)?"active":""}" data-angle="270">270° Kiri</button>
        </div>
      </div>
    `;this.container.innerHTML=t,this.attachEvents()}getAngleLabel(e){return e>=315||e<45?"Tampak Depan (0°)":e>=45&&e<135?"Tampak Samping Kanan (90°)":e>=135&&e<225?"Tampak Belakang (180°)":e>=225&&e<315?"Tampak Samping Kiri (270°)":`${e}°`}isAngleActive(e){const t=Math.abs(this.currentAngle-e);return t<45||t>315}setAngle(e){let t=(e%360+360)%360;this.currentAngle=Math.round(t);const n=this.container.querySelector("#angle-range-slider"),i=this.container.querySelector(".angle-text"),s=this.container.querySelector(".angle-label"),a=this.container.querySelectorAll(".angle-btn");n&&(n.value=this.currentAngle),i&&(i.textContent=`${this.currentAngle}°`),s&&(s.textContent=this.getAngleLabel(this.currentAngle)),a.forEach(o=>{const d=parseInt(o.getAttribute("data-angle"),10);this.isAngleActive(d)?o.classList.add("active"):o.classList.remove("active")}),this.onAngleChange&&this.onAngleChange(this.currentAngle)}attachEvents(){const e=this.container.querySelector("#angle-range-slider"),t=this.container.querySelectorAll(".angle-btn");e&&e.addEventListener("input",i=>{const s=parseInt(i.target.value,10);this.setAngle(s)}),t.forEach(i=>{i.addEventListener("click",()=>{const s=parseInt(i.getAttribute("data-angle"),10);this.setAngle(s)})});const n=document.querySelector(".scene-viewport");n&&(n.addEventListener("mousedown",i=>{i.target.closest(".hotspot-marker")||i.target.closest("button")||(this.isDragging=!0,this.startX=i.clientX,this.startAngle=this.currentAngle,n.style.cursor="grabbing")}),window.addEventListener("mousemove",i=>{if(!this.isDragging)return;const s=i.clientX-this.startX,a=this.startAngle+Math.round(s*.5);this.setAngle(a)}),window.addEventListener("mouseup",()=>{this.isDragging&&(this.isDragging=!1,n&&(n.style.cursor="default"))}))}}class p{constructor(e,t){this.container=e,this.jsonPath=t,this.moduleData=null,this.activeView="",this.activeFilter="all",this.currentAngle=0}async loadData(){try{const e=await fetch(this.jsonPath);this.moduleData=await e.json()}catch(e){console.error(`[BaseModule] Failed to load JSON ${this.jsonPath}`,e)}}async render(){if(this.moduleData||await this.loadData(),!this.moduleData)return;const e=this.moduleData,t=Object.keys(e.centralImages||{});this.activeView=t[0]||"front",this.currentAngle=0;const n=`
      <div class="inspection-workspace">
        <!-- Floating Filter Category Bar -->
        <div class="filter-category-bar">
          ${(e.filterCategories||[]).map(i=>`
            <button class="filter-btn ${i.id==="all"?"active":""}" data-filter="${i.id}">
              ${i.label}
            </button>
          `).join("")}
        </div>

        <!-- Floating Viewport Controls (X-Ray / Normal) -->
        <div id="view-toggle-container"></div>

        <!-- Central Inspection Viewport Scene -->
        <div class="scene-viewport">
          <div class="scene-container">
            <img id="central-scene-image" class="scene-image" 
                 src="${e.centralImages[this.activeView].url}" 
                 alt="${e.centralImages[this.activeView].label}">
            
            <!-- Hotspots Interactive Layer -->
            <div id="hotspot-layer-root"></div>
          </div>
        </div>

        <!-- 360 Rotation Controller Container -->
        <div id="rotation-control-root"></div>

        <!-- Bottom Carousel Bar -->
        <div id="carousel-root"></div>

        <!-- Right Side Info Drawer -->
        <aside id="info-panel-drawer"></aside>
      </div>
    `;this.container.innerHTML=n,this.initComponents(),h.trackModuleView(e.moduleId,e.moduleTitle)}initComponents(){const e=this.moduleData,t=document.getElementById("central-scene-image"),n=document.getElementById("info-panel-drawer"),i=document.getElementById("hotspot-layer-root"),s=document.getElementById("view-toggle-container"),a=document.getElementById("rotation-control-root"),o=document.getElementById("carousel-root");this.infoPanel=new A(n),this.hotspotLayer=new I(i,{onHotspotClick:r=>{this.infoPanel.show(r),this.carousel.render(e.hotspots,r.id),h.trackHotspotClick(e.moduleId,r.id,r.label,r.category)}}),this.viewToggle=new S(s,{onViewChange:r=>{this.activeView=r,e.centralImages[r]&&(t.src=e.centralImages[r].url,t.alt=e.centralImages[r].label),this.hotspotLayer.render(e.hotspots,this.activeView,this.activeFilter,this.currentAngle)}}),e.supportsRotation&&(this.rotationControl=new L(a,{onAngleChange:r=>{this.currentAngle=r,e.angleImages&&(r>=315||r<45?e.angleImages.front&&(t.src=e.angleImages.front):r>=45&&r<135?e.angleImages.side&&(t.src=e.angleImages.side):r>=135&&r<225?e.angleImages.back&&(t.src=e.angleImages.back):r>=225&&r<315&&e.angleImages.side2&&(t.src=e.angleImages.side2)),this.hotspotLayer.render(e.hotspots,this.activeView,this.activeFilter,this.currentAngle)}}),this.rotationControl.render(0)),this.carousel=new E(o,{onSelectHotspot:r=>{r.view&&r.view!==this.activeView&&this.viewToggle.onViewChange(r.view),this.rotationControl&&r.angleMin!==void 0&&this.rotationControl.setAngle(r.angleMin),this.hotspotLayer.markVisited(r.id),this.infoPanel.show(r),h.trackHotspotClick(e.moduleId,r.id,r.label,r.category)}}),this.viewToggle.render(e.centralImages,this.activeView),this.hotspotLayer.render(e.hotspots,this.activeView,this.activeFilter,this.currentAngle),this.carousel.render(e.hotspots);const d=this.container.querySelectorAll(".filter-btn");d.forEach(r=>{r.addEventListener("click",()=>{const c=r.getAttribute("data-filter");this.activeFilter=c,d.forEach(v=>v.classList.remove("active")),r.classList.add("active"),this.hotspotLayer.render(e.hotspots,this.activeView,this.activeFilter,this.currentAngle)})})}}class C extends p{constructor(e){super(e,"src/data/modul1-hotspots.json")}}class M extends p{constructor(e){super(e,"src/data/modul2-hotspots.json")}}class B extends p{constructor(e){super(e,"src/data/modul3-hotspots.json")}}class P extends p{constructor(e){super(e,"src/data/modul4a-hotspots.json")}}class $ extends p{constructor(e){super(e,"src/data/modul4b-hotspots.json")}}class z{constructor(e){this.container=e,this.quizData=null,this.currentIndex=0,this.userAnswers=[],this.isSubmitted=!1}async loadQuestions(){try{const e=await fetch("src/data/evaluasi-questions.json");this.quizData=await e.json()}catch(e){console.error("[Evaluasi] Failed to load quiz JSON",e)}}async render(){this.quizData||await this.loadQuestions(),this.quizData&&(this.currentIndex=0,this.userAnswers=new Array(this.quizData.questions.length).fill(null),this.isSubmitted=!1,this.renderQuestionScreen(),h.trackModuleView("evaluasi","Ujian Evaluasi Modus Penyelundupan Narkotika"))}renderQuestionScreen(){const e=this.quizData.questions[this.currentIndex],t=this.quizData.questions.length,n=this.userAnswers[this.currentIndex],i=`
      <div style="width: 100%; height: 100%; overflow-y: auto; padding: 32px; display: flex; flex-direction: column; align-items: center; justify-content: center;">
        <div style="width: 100%; max-width: 780px; background: var(--bg-dark-800); border: 1px solid var(--surface-glass-border); border-radius: var(--radius-xl); padding: 32px; box-shadow: var(--shadow-lg);">
          
          <!-- Header Progress -->
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; border-bottom: 1px solid var(--surface-glass-border); padding-bottom: 16px;">
            <div>
              <span class="badge badge-gold">${e.category}</span>
              <span style="font-size: 0.85rem; color: var(--text-secondary); margin-left: 8px;">Soal ${this.currentIndex+1} dari ${t}</span>
            </div>
            <div style="font-size: 0.85rem; font-weight: 600; color: var(--accent-gold);">
              Batas Kelulusan: ${this.quizData.passingScorePercent}%
            </div>
          </div>

          <!-- Question Prompt -->
          <h3 style="font-size: 1.15rem; color: #FFF; line-height: 1.5; margin-bottom: 24px;">
            ${e.question}
          </h3>

          <!-- Options List -->
          <div style="display: flex; flex-direction: column; gap: 12px; margin-bottom: 32px;">
            ${e.options.map((s,a)=>{const o=n===a;return`
                <button class="btn btn-outline quiz-option-btn ${o?"active-gold":""}" 
                        data-index="${a}"
                        style="justify-content: flex-start; text-align: left; padding: 14px 18px; ${o?"border-color: var(--accent-gold); background: rgba(245,166,35,0.15);":""}">
                  <span style="width: 26px; height: 26px; border-radius: 50%; background: ${o?"var(--accent-gold)":"rgba(255,255,255,0.1)"}; color: ${o?"#000":"#FFF"}; font-weight: 700; font-size: 0.8rem; display: inline-flex; align-items: center; justify-content: center; flex-shrink: 0; margin-right: 10px;">
                    ${String.fromCharCode(65+a)}
                  </span>
                  <span style="font-size: 0.92rem;">${s}</span>
                </button>
              `}).join("")}
          </div>

          <!-- Navigation Footer -->
          <div style="display: flex; align-items: center; justify-content: space-between; border-top: 1px solid var(--surface-glass-border); padding-top: 20px;">
            <button id="prev-question-btn" class="btn btn-outline" ${this.currentIndex===0?'disabled style="opacity:0.4; cursor:not-allowed;"':""}>
              &larr; Sebelumnya
            </button>

            ${this.currentIndex<t-1?`
              <button id="next-question-btn" class="btn btn-gold">
                Berikutnya &rarr;
              </button>
            `:`
              <button id="submit-quiz-btn" class="btn btn-gold">
                Selesaikan Ujian ✅
              </button>
            `}
          </div>

        </div>
      </div>
    `;this.container.innerHTML=i,this.attachQuestionEvents()}attachQuestionEvents(){this.container.querySelectorAll(".quiz-option-btn").forEach(s=>{s.addEventListener("click",()=>{const a=parseInt(s.getAttribute("data-index"),10);this.userAnswers[this.currentIndex]=a,this.renderQuestionScreen()})});const t=this.container.querySelector("#prev-question-btn");t&&this.currentIndex>0&&t.addEventListener("click",()=>{this.currentIndex--,this.renderQuestionScreen()});const n=this.container.querySelector("#next-question-btn");n&&n.addEventListener("click",()=>{if(this.userAnswers[this.currentIndex]===null){alert("Pilih salah satu jawaban sebelum melanjutkan!");return}this.currentIndex++,this.renderQuestionScreen()});const i=this.container.querySelector("#submit-quiz-btn");i&&i.addEventListener("click",()=>{if(this.userAnswers[this.currentIndex]===null){alert("Pilih salah satu jawaban sebelum menyelesaikan ujian!");return}this.calculateResult()})}calculateResult(){let e=0;const t=this.quizData.questions;t.forEach((a,o)=>{this.userAnswers[o]===a.correctIndex&&e++});const n=t.length,i=Math.round(e/n*100),s=i>=this.quizData.passingScorePercent;m.setCompleted(i),h.trackQuizCompleted(i,s,n),this.renderResultScreen(i,s,e,n)}renderResultScreen(e,t,n,i){const s=`
      <div style="width: 100%; height: 100%; overflow-y: auto; padding: 32px; display: flex; flex-direction: column; align-items: center; justify-content: center;">
        <div style="width: 100%; max-width: 650px; background: var(--bg-dark-800); border: 1px solid var(--surface-glass-border); border-radius: var(--radius-xl); padding: 40px; text-align: center; box-shadow: var(--shadow-lg);">
          
          <div style="font-size: 4rem; margin-bottom: 12px;">
            ${t?"🏆":"⚠️"}
          </div>

          <h2 style="font-size: 1.8rem; color: #FFF; margin-bottom: 8px;">
            ${t?"Selamat! Anda Lulus Evaluasi":"Belum Mencapai Batas Kelulusan"}
          </h2>

          <div style="font-size: 3rem; font-weight: 800; color: ${t?"#34C759":"#FF3B30"}; margin: 16px 0;">
            ${e}%
          </div>

          <p style="font-size: 0.95rem; color: var(--text-secondary); margin-bottom: 24px;">
            Anda menjawab benar <strong>${n}</strong> dari <strong>${i}</strong> soal scenario.<br>
            Batas kelulusan minimum: ${this.quizData.passingScorePercent}%. Status kelulusan SCORM telah dicatat ke KLC.
          </p>

          <div style="display: flex; gap: 16px; justify-content: center;">
            <button id="retake-quiz-btn" class="btn btn-outline">
              🔄 Ulangi Ujian
            </button>
            <a href="#/beranda" class="btn btn-gold">
              🏠 Kembali ke Beranda
            </a>
          </div>

        </div>
      </div>
    `;this.container.innerHTML=s;const a=this.container.querySelector("#retake-quiz-btn");a&&a.addEventListener("click",()=>this.render())}}class F{constructor(e){this.container=e,this.routes={beranda:b,modul1:C,modul2:M,modul3:B,modul4a:P,modul4b:$,evaluasi:z},this.currentViewInstance=null}init(){window.addEventListener("hashchange",()=>this.handleRoute());const e=m.getBookmark();e&&this.routes[e]&&!window.location.hash?window.location.hash=`#/${e}`:window.location.hash||(window.location.hash="#/beranda"),this.handleRoute()}async handleRoute(){const t=(window.location.hash.replace(/^#\//,"")||"beranda").toLowerCase(),n=this.routes[t]||b;this.updateSidebarActive(t),m.setBookmark(t),this.currentViewInstance=new n(this.container),await this.currentViewInstance.render(),this.container.scrollTop=0}updateSidebarActive(e){document.querySelectorAll("#sidebar .nav-item").forEach(s=>{s.getAttribute("data-route")===e?(s.classList.add("active"),s.style.color="var(--accent-gold)",s.style.background="var(--bg-dark-600)"):(s.classList.remove("active"),s.style.color="var(--text-secondary)",s.style.background="transparent")});const n=document.getElementById("page-title"),i={beranda:"Beranda & Panduan Inspeksi",modul1:"Modul 1: Penyelundupan Melalui Tubuh Kurir",modul2:"Modul 2: Penyelundupan Melalui Barang Bawaan",modul3:"Modul 3: Penyelundupan Melalui Barang Kiriman",modul4a:"Modul 4A: Penyelundupan Melalui Kendaraan Darat (SUV)",modul4b:"Modul 4B: Penyelundupan Melalui Kapal Laut Cargo",evaluasi:"Ujian Evaluasi Modus Penyelundupan Narkotika"};n&&(n.textContent=i[e]||"Modul Inspeksi DJBC")}}class R{constructor(){this.container=document.getElementById("modal-root")}render(){const e=u.getConfig(),t=`
      <div id="lrs-modal-backdrop" class="modal-backdrop open">
        <div class="modal-card animate-slide-up">
          <div class="modal-header">
            <div style="display: flex; align-items: center; gap: 10px;">
              <span style="font-size: 1.3rem;">⚙️</span>
              <h3 style="margin: 0; font-size: 1.1rem; color: #FFF;">Pengaturan LRS / xAPI Analytics</h3>
            </div>
            <button id="close-lrs-modal-btn" class="btn-icon" style="width:32px; height:32px;">✕</button>
          </div>

          <form id="lrs-config-form">
            <p style="font-size: 0.82rem; color: var(--text-secondary); margin-bottom: 16px;">
              Masukkan detail Learning Record Store (LRS) untuk mengirim analytics interaksi peserta secara real-time via xAPI.
            </p>

            <div class="form-group">
              <label for="lrs-endpoint">LRS Endpoint URL</label>
              <input type="url" id="lrs-endpoint" class="form-control" 
                     placeholder="https://lrs.kemenkeu.go.id/xAPI/" 
                     value="${e.endpoint||""}" required>
            </div>

            <div class="form-group">
              <label for="lrs-username">LRS Basic Auth Username / Key</label>
              <input type="text" id="lrs-username" class="form-control" 
                     placeholder="Contoh: djbc_lms_key" 
                     value="${e.username||""}" required>
            </div>

            <div class="form-group">
              <label for="lrs-password">LRS Basic Auth Password / Secret</label>
              <input type="password" id="lrs-password" class="form-control" 
                     placeholder="••••••••••••••••" 
                     value="${e.password||""}" required>
            </div>

            <div class="form-group" style="flex-direction: row; align-items: center; gap: 10px; margin-top: 10px;">
              <input type="checkbox" id="lrs-enabled" ${e.enabled?"checked":""}>
              <label for="lrs-enabled" style="margin: 0; cursor: pointer;">Aktifkan Pengiriman xAPI Statement</label>
            </div>

            <div id="lrs-test-status" style="margin: 12px 0; font-size: 0.82rem; display: none; padding: 8px 12px; border-radius: 6px;"></div>

            <div style="display: flex; align-items: center; justify-content: flex-end; gap: 12px; margin-top: 20px;">
              <button type="button" id="test-lrs-btn" class="btn btn-outline">Uji Koneksi</button>
              <button type="submit" class="btn btn-gold">Simpan Pengaturan</button>
            </div>
          </form>
        </div>
      </div>
    `;this.container.innerHTML=t,this.attachEvents()}attachEvents(){const e=document.getElementById("lrs-modal-backdrop"),t=document.getElementById("close-lrs-modal-btn"),n=document.getElementById("lrs-config-form"),i=document.getElementById("test-lrs-btn"),s=document.getElementById("lrs-test-status"),a=()=>{e.classList.remove("open"),setTimeout(()=>{this.container.innerHTML=""},300)};t.addEventListener("click",a),e.addEventListener("click",o=>{o.target===e&&a()}),i.addEventListener("click",async()=>{const o=document.getElementById("lrs-endpoint").value,d=document.getElementById("lrs-username").value,r=document.getElementById("lrs-password").value;s.style.display="block",s.style.background="rgba(255, 149, 0, 0.2)",s.style.color="#FFB340",s.innerText="Menguji koneksi ke LRS...";const c=await u.testConnection(o,d,r);c.success?(s.style.background="rgba(52, 199, 89, 0.2)",s.style.color="#5CD97D",s.innerText=c.message):(s.style.background="rgba(255, 59, 48, 0.2)",s.style.color="#FF6B6B",s.innerText=c.message)}),n.addEventListener("submit",o=>{o.preventDefault();const d=document.getElementById("lrs-endpoint").value,r=document.getElementById("lrs-username").value,c=document.getElementById("lrs-password").value,v=document.getElementById("lrs-enabled").checked;u.saveConfig(d,r,c,v);const f=document.getElementById("lrs-status-dot");f&&(f.style.background=v?"#34C759":"#64748B"),a()})}}class V{static async init(){console.log("[App] Initializing Interactive Narcotics Concealment Inspection Simulator..."),m.init(),await g.init();const e=document.getElementById("lrs-config-btn"),t=document.getElementById("lrs-status-dot");t&&(t.style.background=u.isConfigured()?"#34C759":"#64748B"),e&&e.addEventListener("click",()=>{new R().render()});const n=document.getElementById("sidebar"),i=document.getElementById("sidebar-toggle-btn");i&&n&&i.addEventListener("click",()=>{n.classList.toggle("collapsed")});const s=document.getElementById("content-area");new F(s).init(),window.addEventListener("beforeunload",()=>{m.terminate()})}}document.addEventListener("DOMContentLoaded",()=>{V.init()});
//# sourceMappingURL=index-CM1sH6ec.js.map
