(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const i of document.querySelectorAll('link[rel="modulepreload"]'))n(i);new MutationObserver(i=>{for(const a of i)if(a.type==="childList")for(const s of a.addedNodes)s.tagName==="LINK"&&s.rel==="modulepreload"&&n(s)}).observe(document,{childList:!0,subtree:!0});function t(i){const a={};return i.integrity&&(a.integrity=i.integrity),i.referrerPolicy&&(a.referrerPolicy=i.referrerPolicy),i.crossOrigin==="use-credentials"?a.credentials="include":i.crossOrigin==="anonymous"?a.credentials="omit":a.credentials="same-origin",a}function n(i){if(i.ep)return;i.ep=!0;const a=t(i);fetch(i.href,a)}})();class b{constructor(){this.api=null,this.version=null,this.isInitialized=!1,this.learnerName="",this.learnerId=""}findAPI(e){let t=0,n=e;for(;n&&t<10;){if(n.API_1484_11)return this.version="2004",n.API_1484_11;if(n.API)return this.version="1.2",n.API;if(n.parent&&n.parent!==n)n=n.parent;else if(n.opener)n=n.opener;else break;t++}return null}init(){if(this.api=this.findAPI(window),!this.api)return console.warn("[SCORM] No SCORM API found. Running in standalone LMS simulation mode."),!1;try{let e=!1;this.version==="2004"?e=this.api.Initialize(""):this.version==="1.2"&&(e=this.api.LMSInitialize("")),this.isInitialized=e==="true"||e===!0,this.isInitialized?(this.fetchLearnerInfo(),console.log(`[SCORM] Successfully initialized SCORM ${this.version} API.`)):console.error("[SCORM] API Initialize failed.")}catch(e){console.error("[SCORM] Exception during initialization:",e)}return this.isInitialized}fetchLearnerInfo(){this.isInitialized&&(this.version==="2004"?(this.learnerName=this.getValue("cmi.learner_name"),this.learnerId=this.getValue("cmi.learner_id")):(this.learnerName=this.getValue("cmi.core.student_name"),this.learnerId=this.getValue("cmi.core.student_id")))}getValue(e){if(!this.isInitialized||!this.api)return"";try{return this.version==="2004"?this.api.GetValue(e):this.api.LMSGetValue(e)}catch(t){return console.error(`[SCORM] GetValue failed for ${e}`,t),""}}setValue(e,t){if(!this.isInitialized||!this.api)return!1;try{let n;return this.version==="2004"?n=this.api.SetValue(e,String(t)):n=this.api.LMSSetValue(e,String(t)),n==="true"||n===!0}catch(n){return console.error(`[SCORM] SetValue failed for ${e}`,n),!1}}commit(){if(!this.isInitialized||!this.api)return!1;try{return this.version==="2004"?this.api.Commit("")==="true":this.api.LMSCommit("")==="true"}catch(e){return console.error("[SCORM] Commit failed",e),!1}}terminate(){if(!this.isInitialized||!this.api)return!1;try{let e;return this.version==="2004"?e=this.api.Terminate(""):e=this.api.LMSFinish(""),this.isInitialized=!1,e==="true"||e===!0}catch(e){return console.error("[SCORM] Terminate failed",e),!1}}setBookmark(e){this.version==="2004"?this.setValue("cmi.location",e):this.setValue("cmi.core.lesson_location",e),this.commit()}getBookmark(){return this.version==="2004"?this.getValue("cmi.location"):this.getValue("cmi.core.lesson_location")}setCompleted(e=100){this.version==="2004"?(this.setValue("cmi.completion_status","completed"),this.setValue("cmi.success_status",e>=70?"passed":"failed"),this.setValue("cmi.score.scaled",(e/100).toFixed(2)),this.setValue("cmi.score.raw",e),this.setValue("cmi.score.min","0"),this.setValue("cmi.score.max","100")):(this.setValue("cmi.core.lesson_status",e>=70?"passed":"completed"),this.setValue("cmi.core.score.raw",e)),this.commit()}}const m=new b;class w{constructor(){this._profile=null,this._isLoaded=!1,this._authMethod="UNINITIALIZED",this.DEFAULT_PROFILE={username:"pegawai_djbc",nip:"199001012015011001",name:"Pegawai DJBC (Simulasi)",email:"pegawai.djbc@kemenkeu.go.id",role:"PEGAWAI",avatarUrl:"",unit:"Direktorat Jenderal Bea dan Cukai",organisasi:"Kementerian Keuangan RI"}}async init(){if(this._isLoaded)return this._profile;try{const i=await fetch("/office/api/auth/session",{credentials:"include"});if(i.ok){const a=await i.json();if(a&&(a.user||a.username||a.name)){const s=a.user||a;return this._profile={username:s.username||s.nip||s.email||"pegawai_klc",nip:s.nip||s.username||"",name:s.name||s.nama||s.displayName||"Pegawai DJBC",email:s.email||`${s.username||"pegawai"}@kemenkeu.go.id`,role:(s.role||s.jabatan||"PEGAWAI").toUpperCase(),avatarUrl:s.avatarUrl||s.avatar||s.foto||"",unit:s.unit||s.unitKerja||"Direktorat Jenderal Bea dan Cukai",organisasi:s.organisasi||"Kementerian Keuangan RI"},this._authMethod="SESSION_API",this._isLoaded=!0,this.updateDOM(),this._profile}}}catch{}const e=new URLSearchParams(window.location.search);if(e.has("username")||e.has("nip"))return this._profile={username:e.get("username")||e.get("nip"),nip:e.get("nip")||e.get("username"),name:e.get("name")||e.get("username")||"Pegawai DJBC",email:e.get("email")||"pegawai@kemenkeu.go.id",role:(e.get("role")||"PEGAWAI").toUpperCase(),avatarUrl:e.get("avatar")||"",unit:"Direktorat Jenderal Bea dan Cukai",organisasi:"Kementerian Keuangan RI"},this._authMethod="URL_PARAMS",this._isLoaded=!0,this.updateDOM(),this._profile;const t=window.scormInstance?window.scormInstance.learnerName:"",n=window.scormInstance?window.scormInstance.learnerId:"";return t||n?(this._profile={username:n||"scorm_user",nip:n||"",name:t||"Pegawai SCORM",email:`${n||"pegawai"}@kemenkeu.go.id`,role:"PEGAWAI",avatarUrl:"",unit:"Direktorat Jenderal Bea dan Cukai",organisasi:"Kementerian Keuangan RI"},this._authMethod="SCORM_API",this._isLoaded=!0,this.updateDOM(),this._profile):(this._profile={...this.DEFAULT_PROFILE},this._authMethod="DEFAULT_FALLBACK",this._isLoaded=!0,this.updateDOM(),this._profile)}getProfile(){return this._profile||this.DEFAULT_PROFILE}getAuthMethod(){return this._authMethod}getActorForXAPI(){const e=this.getProfile();return{objectType:"Agent",name:e.name,mbox:`mailto:${e.email}`,account:{homePage:"https://klc2.kemenkeu.go.id",name:e.username||e.nip}}}updateDOM(){const e=this.getProfile(),t=document.getElementById("user-display-name"),n=document.getElementById("user-display-role"),i=document.getElementById("user-avatar-img"),a=document.getElementById("user-avatar-placeholder"),s=document.getElementById("user-avatar-initials");if(t&&(t.textContent=e.name),n&&(n.textContent=`${e.role} — ${e.unit}`),e.avatarUrl&&i)i.src=e.avatarUrl,i.style.display="block",a&&(a.style.display="none"),s&&(s.style.display="none");else if(s){i&&(i.style.display="none"),a&&(a.style.display="none"),s.style.display="block";const o=e.name.split(" ").map(c=>c[0]).join("").substring(0,2).toUpperCase();s.textContent=o||"BC"}}}const g=new w;class k{constructor(){this.STORAGE_KEY="djbc_lrs_config",this.config=this.loadConfig()}loadConfig(){try{const e=localStorage.getItem(this.STORAGE_KEY);if(e)return JSON.parse(e)}catch(e){console.error("[LRSConfig] Failed to load config",e)}return{endpoint:"",username:"",password:"",enabled:!1}}saveConfig(e,t,n,i=!0){let a=(e||"").trim();a&&!a.endsWith("/")&&(a+="/"),this.config={endpoint:a,username:(t||"").trim(),password:(n||"").trim(),enabled:!!i};try{localStorage.setItem(this.STORAGE_KEY,JSON.stringify(this.config))}catch(s){console.error("[LRSConfig] Failed to save config",s)}return this.config}getConfig(){return{...this.config}}isConfigured(){return!!(this.config.enabled&&this.config.endpoint&&this.config.username)}getAuthHeader(){return!this.config.username||!this.config.password?"":"Basic "+btoa(`${this.config.username}:${this.config.password}`)}async testConnection(e,t,n){let i=(e||"").trim();i.endsWith("/")||(i+="/"),i+="about";const a={"X-Experience-API-Version":"1.0.3"};t&&n&&(a.Authorization="Basic "+btoa(`${t}:${n}`));try{const s=await fetch(i,{method:"GET",headers:a});return s.ok?{success:!0,message:"Koneksi ke LRS berhasil!",version:(await s.json().catch(()=>({}))).version||["1.0.3"]}:{success:!1,message:`LRS merespon HTTP ${s.status} (${s.statusText})`}}catch(s){return{success:!1,message:`Gagal menghubungi LRS: ${s.message}`}}}}const u=new k;class x{constructor(){this.BASE_URL=window.location.origin+window.location.pathname}getVerbs(){return{launched:{id:"http://adlnet.gov/expapi/verbs/launched",display:{"id-ID":"memulai"}},initialized:{id:"http://adlnet.gov/expapi/verbs/initialized",display:{"id-ID":"menginisialisasi"}},interacted:{id:"http://adlnet.gov/expapi/verbs/interacted",display:{"id-ID":"berinteraksi"}},viewed:{id:"http://id.tincanapi.com/verb/viewed",display:{"id-ID":"melihat"}},answered:{id:"http://adlnet.gov/expapi/verbs/answered",display:{"id-ID":"menjawab"}},completed:{id:"http://adlnet.gov/expapi/verbs/completed",display:{"id-ID":"menyelesaikan"}},passed:{id:"http://adlnet.gov/expapi/verbs/passed",display:{"id-ID":"lulus"}},failed:{id:"http://adlnet.gov/expapi/verbs/failed",display:{"id-ID":"gagal"}}}}buildStatement({verb:e,activityId:t,activityName:n,activityDesc:i,result:a,contextExtensions:s}){const c={actor:g.getActorForXAPI(),verb:e,object:{objectType:"Activity",id:`${this.BASE_URL}#/${t}`,definition:{name:{"id-ID":n,"en-US":n},description:{"id-ID":i||n}}},timestamp:new Date().toISOString(),context:{registration:this.getRegistrationId(),contextActivities:{parent:[{id:`${this.BASE_URL}#/module-inspection-suite`,definition:{name:{"id-ID":"Modul Interaktif Penyelundupan Narkotika DJBC"}}}]},extensions:{"http://klc2.kemenkeu.go.id/xapi/extensions/unit":g.getProfile().unit,"http://klc2.kemenkeu.go.id/xapi/extensions/role":g.getProfile().role,...s||{}}}};return a&&(c.result=a),c}getRegistrationId(){let e=sessionStorage.getItem("xapi_registration_id");return e||(e="reg-"+Math.random().toString(36).substring(2,11)+"-"+Date.now(),sessionStorage.setItem("xapi_registration_id",e)),e}async sendStatement(e){if(console.log("[xAPI Statement Generated]",e),!u.isConfigured())return{sent:!1,reason:"LRS not configured or disabled"};const n=u.getConfig().endpoint+"statements";try{const i=await fetch(n,{method:"POST",headers:{"Content-Type":"application/json","X-Experience-API-Version":"1.0.3",Authorization:u.getAuthHeader()},body:JSON.stringify(e)});return i.ok?(console.log("[xAPI Statement Successfully Sent to LRS]"),{sent:!0}):(console.warn(`[xAPI Send Failed] HTTP ${i.status}`,await i.text().catch(()=>"")),{sent:!1,reason:`HTTP ${i.status}`})}catch(i){return console.error("[xAPI Exception]",i),{sent:!1,reason:i.message}}}trackModuleView(e,t){const n=this.getVerbs(),i=this.buildStatement({verb:n.launched,activityId:e,activityName:`Modul Inspeksi: ${t}`,activityDesc:`Peserta membuka halaman modul ${t}`});this.sendStatement(i)}trackHotspotClick(e,t,n,i){const a=this.getVerbs(),s=this.buildStatement({verb:a.interacted,activityId:`${e}/hotspot/${t}`,activityName:`Hotspot: ${n}`,activityDesc:`Peserta mengeklik hotspot ${n} pada modul ${e}`,contextExtensions:{"http://klc2.kemenkeu.go.id/xapi/extensions/category":i,"http://klc2.kemenkeu.go.id/xapi/extensions/module":e}});this.sendStatement(s)}trackQuizCompleted(e,t,n){const i=this.getVerbs(),a=t?i.passed:i.failed,s=this.buildStatement({verb:a,activityId:"evaluasi-narkotika-djbc",activityName:"Ujian Evaluasi Modus Penyelundupan Narkotika",result:{score:{scaled:(e/100).toFixed(2),raw:e,min:0,max:100},success:t,completion:!0}});this.sendStatement(s)}}const h=new x;class y{constructor(e){this.container=e}async render(){const e=g.getProfile(),t=`
      <div style="width: 100%; height: 100%; overflow-y: auto; padding: var(--container-padding); display: flex; flex-direction: column; gap: var(--space-4); max-width: var(--content-max); margin: 0 auto;">
        
        <!-- Hero Section (Dharma Bhakti Atlas Style) -->
        <section style="background: linear-gradient(135deg, var(--color-primary-container) 0%, #001530 100%); color: white; border-radius: var(--radius-xl); padding: 48px; position: relative; overflow: hidden; box-shadow: var(--shadow-card);">
          <div style="max-width: 780px; position: relative; z-index: 2;">
            <span class="badge badge-gold" style="margin-bottom: 16px;">
              MP3 — Modus Operandi & Inspeksi Narkotika DJBC
            </span>
            <h1 style="font-size: var(--font-size-display); font-weight: 700; color: #FFFFFF; line-height: 1.15; margin-bottom: 16px;">
              Interactive Narcotics Inspection Simulator
            </h1>
            <p style="font-size: var(--font-size-body-lg); color: rgba(255, 255, 255, 0.9); margin-bottom: 28px; line-height: 1.6;">
              Selamat datang, <strong style="color: var(--color-secondary-container);">${e.name}</strong> (${e.nip||e.username}). Media pembelajaran interaktif berbasis simulasi pengawasan X-Ray, 360° rotation, dan hotspot inspeksi untuk mendeteksi titik-titik penyembunyian Narkotika pada 4 kategori utama.
            </p>
            <div style="display: flex; gap: 16px; flex-wrap: wrap;">
              <a href="#/modul1" class="btn btn-secondary btn-lg">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/></svg>
                Mulai Inspeksi Modul 1
              </a>
              <a href="#/evaluasi" class="btn btn-ghost btn-lg" style="color: white; border-color: rgba(255,255,255,0.4);">
                Uji Pemahaman (Evaluasi)
              </a>
            </div>
          </div>
        </section>

        <!-- Mandatory Disclaimer Banner -->
        <div class="disclaimer-banner">
          <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>
          <div>
            <strong>Disclaimer Resmi Kemenkeu & DJBC:</strong> Simulasi inspeksi ini dikembangkan khusus untuk tujuan pembelajaran mandiri dan peningkatan ketajaman teknis pegawai Direktorat Jenderal Bea dan Cukai. Tindakan interdiksi resmi di lapangan wajib mematuhi SOP dan petunjuk teknis DJBC yang berlaku.
          </div>
        </div>

        <!-- Learning Objectives Grid -->
        <section style="margin-bottom: 24px;">
          <h2 style="font-size: var(--font-size-headline-md); font-weight: 700; margin-bottom: 16px; color: var(--color-primary-container);">
            Tujuan Pembelajaran Mandiri
          </h2>
          <div class="grid-3col">
            <div class="card">
              <div style="width: 48px; height: 48px; background: #e0f2fe; color: #0284c7; border-radius: var(--radius-md); display: flex; align-items: center; justify-content: center; margin-bottom: 16px; font-weight: bold; font-size: 20px;">01</div>
              <h3 style="font-size: var(--font-size-title-lg); font-weight: 600; margin-bottom: 8px;">Identifikasi Modus</h3>
              <p style="font-size: var(--font-size-body-md); color: var(--color-on-surface-variant);">Memahami pemetaan metode concealment pada tubuh kurir, barang bawaan, barang kiriman pos/PJT, serta sarana pengangkut darat dan laut.</p>
            </div>
            <div class="card">
              <div style="width: 48px; height: 48px; background: #fef3c7; color: #d97706; border-radius: var(--radius-md); display: flex; align-items: center; justify-content: center; margin-bottom: 16px; font-weight: bold; font-size: 20px;">02</div>
              <h3 style="font-size: var(--font-size-title-lg); font-weight: 600; margin-bottom: 8px;">Analisis Citra X-Ray</h3>
              <p style="font-size: var(--font-size-body-md); color: var(--color-on-surface-variant);">Mengamati citra X-Ray, Cutaway View, dan 360° Rotation dengan hotspot interaktif untuk mengenali indikator risiko (red flags).</p>
            </div>
            <div class="card">
              <div style="width: 48px; height: 48px; background: #dcfce7; color: #15803d; border-radius: var(--radius-md); display: flex; align-items: center; justify-content: center; margin-bottom: 16px; font-weight: bold; font-size: 20px;">03</div>
              <h3 style="font-size: var(--font-size-title-lg); font-weight: 600; margin-bottom: 8px;">Penerapan SOP Bea Cukai</h3>
              <p style="font-size: var(--font-size-body-md); color: var(--color-on-surface-variant);">Mempelajari langkah penindakan, penggeledahan fisik, uji reagen laboratorium, dan evakuasi medis sesuai standar DJBC.</p>
            </div>
          </div>
        </section>

        <!-- 4 Key Modules Interactive Grid -->
        <section style="margin-bottom: 32px;">
          <h2 style="font-size: var(--font-size-headline-md); font-weight: 700; margin-bottom: 16px; color: var(--color-primary-container);">
            Modul Inspeksi Interaktif
          </h2>
          <div class="grid-2col">
            
            <!-- Modul 1 Card -->
            <a href="#/modul1" class="card card-interactive" style="display: flex; gap: 20px; align-items: center; text-decoration: none; color: inherit;">
              <div style="width: 64px; height: 64px; background-color: var(--color-primary-container); color: white; border-radius: var(--radius-md); display: flex; align-items: center; justify-content: center; flex-shrink: 0; font-size: 28px;">
                👤
              </div>
              <div>
                <h3 style="font-size: var(--font-size-title-lg); font-weight: 700; margin-bottom: 4px;">1. Tubuh Kurir (Body Concealment)</h3>
                <p style="color: var(--color-on-surface-variant); font-size: var(--font-size-body-md);">Inspeksi 360° anatomi & X-Ray tubuh: Ingestion (telan), Insertion (anal/vaginal), Body Strapping, & Modus Terkini.</p>
              </div>
            </a>

            <!-- Modul 2 Card -->
            <a href="#/modul2" class="card card-interactive" style="display: flex; gap: 20px; align-items: center; text-decoration: none; color: inherit;">
              <div style="width: 64px; height: 64px; background-color: var(--color-secondary-container); color: #261a00; border-radius: var(--radius-md); display: flex; align-items: center; justify-content: center; flex-shrink: 0; font-size: 28px;">
                🧳
              </div>
              <div>
                <h3 style="font-size: var(--font-size-title-lg); font-weight: 700; margin-bottom: 4px;">2. Barang Bawaan (Luggage)</h3>
                <p style="color: var(--color-on-surface-variant); font-size: var(--font-size-body-md);">Pemeriksaan koper bagasi penumpang: False Bottom, Dinding Ganda, Rangka Trolley, Sepatu (False Sole), & Buku.</p>
              </div>
            </a>

            <!-- Modul 3 Card -->
            <a href="#/modul3" class="card card-interactive" style="display: flex; gap: 20px; align-items: center; text-decoration: none; color: inherit;">
              <div style="width: 64px; height: 64px; background-color: var(--color-primary-container); color: white; border-radius: var(--radius-md); display: flex; align-items: center; justify-content: center; flex-shrink: 0; font-size: 28px;">
                📦
              </div>
              <div>
                <h3 style="font-size: var(--font-size-title-lg); font-weight: 700; margin-bottom: 4px;">3. Barang Kiriman (Postal Cargo)</h3>
                <p style="color: var(--color-on-surface-variant); font-size: var(--font-size-body-md);">Inspeksi kargo Pos & PJT: Kaleng Makanan (Liquid Meth), Kardus Corrugated, Elektronik, & Kemasan Teh Guanyinwang.</p>
              </div>
            </a>

            <!-- Modul 4A & 4B Card -->
            <a href="#/modul4a" class="card card-interactive" style="display: flex; gap: 20px; align-items: center; text-decoration: none; color: inherit;">
              <div style="width: 64px; height: 64px; background-color: var(--color-secondary-container); color: #261a00; border-radius: var(--radius-md); display: flex; align-items: center; justify-content: center; flex-shrink: 0; font-size: 28px;">
                🚗
              </div>
              <div>
                <h3 style="font-size: var(--font-size-title-lg); font-weight: 700; margin-bottom: 4px;">4. Sarana Pengangkut (Darat & Laut)</h3>
                <p style="color: var(--color-on-surface-variant); font-size: var(--font-size-body-md);">Inspeksi 360° Kompartemen Pintu Mobil, Tangki Bahan Bakar Dinding Ganda, Kontainer Reefer, & Kapal Kargo.</p>
              </div>
            </a>

          </div>
        </section>

      </div>
    `;this.container.innerHTML=t,h.trackModuleView("beranda","Beranda & Panduan Inspeksi")}}class I{constructor(e,{onHotspotClick:t}){this.container=e,this.onHotspotClick=t,this.visitedSet=new Set,this.activeFilter="all",this.activeView="front",this.hotspots=[]}render(e,t="front",n="all",i=0){this.hotspots=e,this.activeView=t,this.activeFilter=n;const a=e.filter(s=>{const o=s.view?s.view===t:!0,c=n==="all"||s.category===n;let r=!0;return s.angleMin!==void 0&&s.angleMax!==void 0&&(s.angleMin<=s.angleMax?r=i>=s.angleMin&&i<=s.angleMax:r=i>=s.angleMin||i<=s.angleMax),o&&c&&r});this.container.innerHTML=a.map(s=>`
        <div class="hotspot-marker ${this.visitedSet.has(s.id)?"visited":""} animate-fade-in" 
             data-id="${s.id}" 
             style="left: ${s.position.x}%; top: ${s.position.y}%;">
          <div class="hotspot-pulse"></div>
          <div class="hotspot-inner"></div>
          <div class="hotspot-tooltip">${s.label}</div>
        </div>
      `).join(""),this.attachEvents()}attachEvents(){this.container.querySelectorAll(".hotspot-marker").forEach(t=>{t.addEventListener("click",n=>{n.stopPropagation();const i=t.getAttribute("data-id");this.visitedSet.add(i),t.classList.add("visited");const a=this.hotspots.find(s=>s.id===i);a&&this.onHotspotClick&&this.onHotspotClick(a)})})}markVisited(e){this.visitedSet.add(e);const t=this.container.querySelector(`.hotspot-marker[data-id="${e}"]`);t&&t.classList.add("visited")}getVisitedCount(){return this.visitedSet.size}}class S{constructor(e){this.drawer=e,this.currentData=null}show(e){this.currentData=e;const t=e.badgeType?`badge-${e.badgeType}`:"badge-danger",n=(e.riskIndicators||[]).map(o=>`
      <div class="risk-item">
        <span>⚠️</span>
        <div>${o}</div>
      </div>
    `).join(""),i=(e.inspectionActions||[]).map(o=>`
      <div class="action-item">
        <span>🔍</span>
        <div>${o}</div>
      </div>
    `).join(""),a=`
      <div class="drawer-header">
        <div>
          <span class="badge ${t}" style="margin-bottom: 8px;">${e.badge||"MODUS PENYELUNDUPAN"}</span>
          <h3 style="margin: 0; font-size: var(--font-size-title-lg); color: var(--color-primary-container); line-height: 1.3;">${e.label}</h3>
        </div>
        <button id="close-info-drawer-btn" class="btn-icon" style="width:34px; height:34px; flex-shrink: 0;">✕</button>
      </div>

      <div class="drawer-body">
        <!-- Hotspot Main Realistic Image -->
        <div class="drawer-image-container">
          <img src="${e.mainImage}" alt="${e.label}" 
               onerror="this.onerror=null; this.src='assets/images/central/m1_body_front_xray.png';">
          <div style="position: absolute; bottom: 8px; right: 8px; background: rgba(0,25,60,0.85); color: #FFF; padding: 2px 10px; border-radius: 4px; font-size: 11px; font-weight: 600;">
            Visual Modus Realistis
          </div>
        </div>

        <!-- Deskripsi Modus -->
        <div>
          <h4 style="font-size: var(--font-size-label-md); font-weight: 700; color: var(--color-primary-container); margin-bottom: 6px;">DESKRIPSI MODUS PENYELUNDUPAN</h4>
          <p style="font-size: var(--font-size-body-md); color: var(--color-on-surface); line-height: 1.6;">${e.description}</p>
        </div>

        <!-- Indikator Resiko / Anomali -->
        <div>
          <h4 style="font-size: var(--font-size-label-md); font-weight: 700; color: var(--color-warning); margin-bottom: 6px;">INDIKATOR RISIKO & ANOMALI (RED FLAGS)</h4>
          <div class="risk-list">
            ${n}
          </div>
        </div>

        <!-- Tindakan Inspeksi DJBC -->
        <div>
          <h4 style="font-size: var(--font-size-label-md); font-weight: 700; color: var(--color-info-risk); margin-bottom: 6px;">SOP TINDAKAN INSPEKSI BEA CUKAI</h4>
          <div class="action-list">
            ${i}
          </div>
        </div>
      </div>
    `;this.drawer.innerHTML=a,this.drawer.classList.add("open");const s=this.drawer.querySelector("#close-info-drawer-btn");s&&s.addEventListener("click",()=>this.hide())}hide(){this.drawer.classList.remove("open")}}class A{constructor(e,{onViewChange:t}){this.container=e,this.onViewChange=t,this.currentViewKey=""}render(e,t){this.currentViewKey=t;const n=Object.keys(e||{});if(n.length<=1){this.container.innerHTML="";return}const i=`
      <div class="view-mode-toggle">
        ${n.map(a=>{const s=e[a];return`
            <button class="view-mode-btn ${a===t?"active":""}" data-key="${a}">
              ${s.label||a.toUpperCase()}
            </button>
          `}).join("")}
      </div>
    `;this.container.innerHTML=i,this.attachEvents()}attachEvents(){const e=this.container.querySelectorAll(".view-mode-btn");e.forEach(t=>{t.addEventListener("click",()=>{const n=t.getAttribute("data-key");n&&n!==this.currentViewKey&&(this.currentViewKey=n,e.forEach(i=>i.classList.remove("active")),t.classList.add("active"),this.onViewChange&&this.onViewChange(n))})})}}class E{constructor(e,{onSelectHotspot:t}){this.container=e,this.onSelectHotspot=t,this.activeId=null}render(e,t=null){if(this.activeId=t,!e||e.length===0){this.container.innerHTML="";return}const n=`
      <div class="bottom-carousel-bar">
        <div style="font-size: 0.75rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase; padding-right: 8px; white-space: nowrap;">
          DAFTAR HOTSPOT:
        </div>
        ${e.map(i=>`
            <div class="carousel-thumb ${i.id===t?"active":""}" data-id="${i.id}">
              <img src="${i.mainImage}" alt="${i.label}" onerror="this.onerror=null; this.src='assets/images/central/m1_body_front_xray.png';">
              <div class="carousel-thumb-title">${i.label}</div>
            </div>
          `).join("")}
      </div>
    `;this.container.innerHTML=n,this.attachEvents(e)}attachEvents(e){const t=this.container.querySelectorAll(".carousel-thumb");t.forEach(n=>{n.addEventListener("click",()=>{const i=n.getAttribute("data-id"),a=e.find(s=>s.id===i);a&&this.onSelectHotspot&&(t.forEach(s=>s.classList.remove("active")),n.classList.add("active"),this.onSelectHotspot(a))})})}}class L{constructor(e,{onAngleChange:t}){this.container=e,this.onAngleChange=t,this.currentAngle=0,this.isDragging=!1,this.startX=0,this.startAngle=0}render(e=0){this.currentAngle=e;const t=`
      <div class="rotation-control-bar">
        <div class="angle-display">
          <span class="compass-icon">🧭</span>
          <span class="angle-text">${this.currentAngle}°</span>
          <span class="angle-label">${this.getAngleLabel(this.currentAngle)}</span>
        </div>

        <div class="angle-slider-wrapper">
          <input type="range" id="angle-range-slider" min="0" max="359" value="${this.currentAngle}" step="1" class="angle-range-slider">
        </div>

        <div class="angle-quick-btns">
          <button class="angle-btn ${this.isAngleActive(0)?"active":""}" data-angle="0">0° Depan</button>
          <button class="angle-btn ${this.isAngleActive(90)?"active":""}" data-angle="90">90° Kanan</button>
          <button class="angle-btn ${this.isAngleActive(180)?"active":""}" data-angle="180">180° Belakang</button>
          <button class="angle-btn ${this.isAngleActive(270)?"active":""}" data-angle="270">270° Kiri</button>
        </div>
      </div>
    `;this.container.innerHTML=t,this.attachEvents()}getAngleLabel(e){return e>=315||e<45?"Tampak Depan (0°)":e>=45&&e<135?"Tampak Samping Kanan (90°)":e>=135&&e<225?"Tampak Belakang (180°)":e>=225&&e<315?"Tampak Samping Kiri (270°)":`${e}°`}isAngleActive(e){const t=Math.abs(this.currentAngle-e);return t<45||t>315}setAngle(e){let t=(e%360+360)%360;this.currentAngle=Math.round(t);const n=this.container.querySelector("#angle-range-slider"),i=this.container.querySelector(".angle-text"),a=this.container.querySelector(".angle-label"),s=this.container.querySelectorAll(".angle-btn");n&&(n.value=this.currentAngle),i&&(i.textContent=`${this.currentAngle}°`),a&&(a.textContent=this.getAngleLabel(this.currentAngle)),s.forEach(o=>{const c=parseInt(o.getAttribute("data-angle"),10);this.isAngleActive(c)?o.classList.add("active"):o.classList.remove("active")}),this.onAngleChange&&this.onAngleChange(this.currentAngle)}attachEvents(){const e=this.container.querySelector("#angle-range-slider"),t=this.container.querySelectorAll(".angle-btn");e&&e.addEventListener("input",i=>{const a=parseInt(i.target.value,10);this.setAngle(a)}),t.forEach(i=>{i.addEventListener("click",()=>{const a=parseInt(i.getAttribute("data-angle"),10);this.setAngle(a)})});const n=document.querySelector(".scene-viewport");n&&(n.addEventListener("mousedown",i=>{i.target.closest(".hotspot-marker")||i.target.closest("button")||(this.isDragging=!0,this.startX=i.clientX,this.startAngle=this.currentAngle,n.style.cursor="grabbing")}),window.addEventListener("mousemove",i=>{if(!this.isDragging)return;const a=i.clientX-this.startX,s=this.startAngle+Math.round(a*.5);this.setAngle(s)}),window.addEventListener("mouseup",()=>{this.isDragging&&(this.isDragging=!1,n&&(n.style.cursor="default"))}))}}class p{constructor(e,t){this.container=e,this.jsonPath=t,this.moduleData=null,this.activeView="",this.activeFilter="all",this.currentAngle=0}async loadData(){try{const e=await fetch(this.jsonPath);this.moduleData=await e.json()}catch(e){console.error(`[BaseModule] Failed to load JSON ${this.jsonPath}`,e)}}async render(){if(this.moduleData||await this.loadData(),!this.moduleData)return;const e=this.moduleData,t=Object.keys(e.centralImages||{});this.activeView=t[0]||"front",this.currentAngle=0;const n=`
      <div class="inspection-workspace">
        <!-- Floating Filter Category Bar -->
        <div class="filter-category-bar">
          ${(e.filterCategories||[]).map(i=>`
            <button class="filter-btn ${i.id==="all"?"active":""}" data-filter="${i.id}">
              ${i.label}
            </button>
          `).join("")}
        </div>

        <!-- Floating Viewport Controls (X-Ray / Normal) -->
        <div id="view-toggle-container"></div>

        <!-- Central Inspection Viewport Scene -->
        <div class="scene-viewport">
          <div class="scene-container">
            <img id="central-scene-image" class="scene-image" 
                 src="${e.centralImages[this.activeView].url}" 
                 alt="${e.centralImages[this.activeView].label}">
            
            <!-- Hotspots Interactive Layer -->
            <div id="hotspot-layer-root"></div>
          </div>
        </div>

        <!-- 360 Rotation Controller Container -->
        <div id="rotation-control-root"></div>

        <!-- Bottom Carousel Bar -->
        <div id="carousel-root"></div>

        <!-- Right Side Info Drawer -->
        <aside id="info-panel-drawer"></aside>
      </div>
    `;this.container.innerHTML=n,this.initComponents(),h.trackModuleView(e.moduleId,e.moduleTitle)}initComponents(){const e=this.moduleData,t=document.getElementById("central-scene-image"),n=document.getElementById("info-panel-drawer"),i=document.getElementById("hotspot-layer-root"),a=document.getElementById("view-toggle-container"),s=document.getElementById("rotation-control-root"),o=document.getElementById("carousel-root");this.infoPanel=new S(n),this.hotspotLayer=new I(i,{onHotspotClick:r=>{this.infoPanel.show(r),this.carousel.render(e.hotspots,r.id),h.trackHotspotClick(e.moduleId,r.id,r.label,r.category)}}),this.viewToggle=new A(a,{onViewChange:r=>{this.activeView=r,e.centralImages[r]&&(t.src=e.centralImages[r].url,t.alt=e.centralImages[r].label),this.hotspotLayer.render(e.hotspots,this.activeView,this.activeFilter,this.currentAngle)}}),e.supportsRotation&&(this.rotationControl=new L(s,{onAngleChange:r=>{this.currentAngle=r,e.angleImages&&(r>=315||r<45?e.angleImages.front&&(t.src=e.angleImages.front):r>=45&&r<135?e.angleImages.side&&(t.src=e.angleImages.side):r>=135&&r<225?e.angleImages.back&&(t.src=e.angleImages.back):r>=225&&r<315&&e.angleImages.side2&&(t.src=e.angleImages.side2)),this.hotspotLayer.render(e.hotspots,this.activeView,this.activeFilter,this.currentAngle)}}),this.rotationControl.render(0)),this.carousel=new E(o,{onSelectHotspot:r=>{r.view&&r.view!==this.activeView&&this.viewToggle.onViewChange(r.view),this.rotationControl&&r.angleMin!==void 0&&this.rotationControl.setAngle(r.angleMin),this.hotspotLayer.markVisited(r.id),this.infoPanel.show(r),h.trackHotspotClick(e.moduleId,r.id,r.label,r.category)}}),this.viewToggle.render(e.centralImages,this.activeView),this.hotspotLayer.render(e.hotspots,this.activeView,this.activeFilter,this.currentAngle),this.carousel.render(e.hotspots);const c=this.container.querySelectorAll(".filter-btn");c.forEach(r=>{r.addEventListener("click",()=>{const d=r.getAttribute("data-filter");this.activeFilter=d,c.forEach(v=>v.classList.remove("active")),r.classList.add("active"),this.hotspotLayer.render(e.hotspots,this.activeView,this.activeFilter,this.currentAngle)})})}}class C extends p{constructor(e){super(e,"src/data/modul1-hotspots.json")}}class M extends p{constructor(e){super(e,"src/data/modul2-hotspots.json")}}class z extends p{constructor(e){super(e,"src/data/modul3-hotspots.json")}}class B extends p{constructor(e){super(e,"src/data/modul4a-hotspots.json")}}class P extends p{constructor(e){super(e,"src/data/modul4b-hotspots.json")}}class ${constructor(e){this.container=e,this.quizData=null,this.currentIndex=0,this.userAnswers=[],this.isSubmitted=!1}async loadQuestions(){try{const e=await fetch("src/data/evaluasi-questions.json");this.quizData=await e.json()}catch(e){console.error("[Evaluasi] Failed to load quiz JSON",e)}}async render(){this.quizData||await this.loadQuestions(),this.quizData&&(this.currentIndex=0,this.userAnswers=new Array(this.quizData.questions.length).fill(null),this.isSubmitted=!1,this.renderQuestionScreen(),h.trackModuleView("evaluasi","Ujian Evaluasi Modus Penyelundupan Narkotika"))}renderQuestionScreen(){const e=this.quizData.questions[this.currentIndex],t=this.quizData.questions.length,n=this.userAnswers[this.currentIndex],i=`
      <div style="width: 100%; height: 100%; overflow-y: auto; padding: var(--container-padding); display: flex; flex-direction: column; align-items: center; justify-content: center;">
        <div class="card" style="width: 100%; max-width: 820px; padding: 40px;">
          
          <!-- Header Progress -->
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 24px; border-bottom: 1px solid var(--color-outline-variant); padding-bottom: 16px;">
            <div>
              <span class="badge badge-gold">${e.category}</span>
              <span style="font-size: var(--font-size-label-md); color: var(--color-on-surface-variant); margin-left: 8px;">Soal ${this.currentIndex+1} dari ${t}</span>
            </div>
            <div style="font-size: var(--font-size-label-md); font-weight: 700; color: var(--color-primary-container);">
              Batas Kelulusan: ${this.quizData.passingScorePercent}%
            </div>
          </div>

          <!-- Question Prompt -->
          <h3 style="font-size: var(--font-size-title-lg); color: var(--color-primary-container); line-height: 1.5; margin-bottom: 28px;">
            ${e.question}
          </h3>

          <!-- Options List -->
          <div style="display: flex; flex-direction: column; gap: 12px; margin-bottom: 32px;">
            ${e.options.map((a,s)=>`
                <div class="option-card ${n===s?"selected":""}" data-index="${s}">
                  <div class="option-indicator">${String.fromCharCode(65+s)}</div>
                  <div style="font-size: var(--font-size-body-md); color: var(--color-on-surface); font-weight: 500;">${a}</div>
                </div>
              `).join("")}
          </div>

          <!-- Navigation Footer -->
          <div style="display: flex; align-items: center; justify-content: space-between; border-top: 1px solid var(--color-outline-variant); padding-top: 24px;">
            <button id="prev-question-btn" class="btn btn-ghost" ${this.currentIndex===0?'disabled style="opacity:0.4; cursor:not-allowed;"':""}>
              &larr; Sebelumnya
            </button>

            ${this.currentIndex<t-1?`
              <button id="next-question-btn" class="btn btn-secondary btn-lg">
                Berikutnya &rarr;
              </button>
            `:`
              <button id="submit-quiz-btn" class="btn btn-secondary btn-lg">
                Selesaikan Ujian ✅
              </button>
            `}
          </div>

        </div>
      </div>
    `;this.container.innerHTML=i,this.attachQuestionEvents()}attachQuestionEvents(){this.container.querySelectorAll(".option-card").forEach(a=>{a.addEventListener("click",()=>{const s=parseInt(a.getAttribute("data-index"),10);this.userAnswers[this.currentIndex]=s,this.renderQuestionScreen()})});const t=this.container.querySelector("#prev-question-btn");t&&this.currentIndex>0&&t.addEventListener("click",()=>{this.currentIndex--,this.renderQuestionScreen()});const n=this.container.querySelector("#next-question-btn");n&&n.addEventListener("click",()=>{if(this.userAnswers[this.currentIndex]===null){alert("Pilih salah satu jawaban sebelum melanjutkan!");return}this.currentIndex++,this.renderQuestionScreen()});const i=this.container.querySelector("#submit-quiz-btn");i&&i.addEventListener("click",()=>{if(this.userAnswers[this.currentIndex]===null){alert("Pilih salah satu jawaban sebelum menyelesaikan ujian!");return}this.calculateResult()})}calculateResult(){let e=0;const t=this.quizData.questions;t.forEach((s,o)=>{this.userAnswers[o]===s.correctIndex&&e++});const n=t.length,i=Math.round(e/n*100),a=i>=this.quizData.passingScorePercent;m.setCompleted(i),h.trackQuizCompleted(i,a,n),this.renderResultScreen(i,a,e,n)}renderResultScreen(e,t,n,i){const a=`
      <div style="width: 100%; height: 100%; overflow-y: auto; padding: var(--container-padding); display: flex; flex-direction: column; align-items: center; justify-content: center;">
        <div class="card" style="width: 100%; max-width: 680px; padding: 48px; text-align: center;">
          
          <div style="font-size: 4.5rem; margin-bottom: 12px;">
            ${t?"🏆":"⚠️"}
          </div>

          <h2 style="font-size: var(--font-size-headline-lg); color: var(--color-primary-container); margin-bottom: 8px;">
            ${t?"Selamat! Anda Lulus Ujian Evaluasi":"Belum Mencapai Batas Kelulusan"}
          </h2>

          <div style="font-size: 3.5rem; font-weight: 800; color: ${t?"var(--color-success)":"var(--color-error)"}; margin: 16px 0;">
            ${e}%
          </div>

          <p style="font-size: var(--font-size-body-lg); color: var(--color-on-surface-variant); margin-bottom: 32px; line-height: 1.6;">
            Anda menjawab benar <strong>${n}</strong> dari <strong>${i}</strong> soal skenario.<br>
            Batas kelulusan minimum: ${this.quizData.passingScorePercent}%. Hasil kelulusan SCORM telah otomatis disimpan ke KLC.
          </p>

          <div style="display: flex; gap: 16px; justify-content: center; flex-wrap: wrap;">
            <button id="retake-quiz-btn" class="btn btn-ghost btn-lg">
              🔄 Ulangi Ujian
            </button>
            <a href="#/beranda" class="btn btn-secondary btn-lg">
              🏠 Kembali ke Beranda
            </a>
          </div>

        </div>
      </div>
    `;this.container.innerHTML=a;const s=this.container.querySelector("#retake-quiz-btn");s&&s.addEventListener("click",()=>this.render())}}class D{constructor(e){this.container=e,this.routes={beranda:y,modul1:C,modul2:M,modul3:z,modul4a:B,modul4b:P,evaluasi:$},this.currentViewInstance=null}init(){window.addEventListener("hashchange",()=>this.handleRoute());const e=m.getBookmark();e&&this.routes[e]&&!window.location.hash?window.location.hash=`#/${e}`:window.location.hash||(window.location.hash="#/beranda"),this.handleRoute()}async handleRoute(){const t=(window.location.hash.replace(/^#\//,"")||"beranda").toLowerCase(),n=this.routes[t]||y;this.updateSidebarActive(t),m.setBookmark(t),this.currentViewInstance=new n(this.container),await this.currentViewInstance.render(),this.container.scrollTop=0}updateSidebarActive(e){document.querySelectorAll("#sidebar .nav-item").forEach(a=>{a.getAttribute("data-route")===e?(a.classList.add("active"),a.style.color="var(--accent-gold)",a.style.background="var(--bg-dark-600)"):(a.classList.remove("active"),a.style.color="var(--text-secondary)",a.style.background="transparent")});const n=document.getElementById("page-title"),i={beranda:"Beranda & Panduan Inspeksi",modul1:"Modul 1: Penyelundupan Melalui Tubuh Kurir",modul2:"Modul 2: Penyelundupan Melalui Barang Bawaan",modul3:"Modul 3: Penyelundupan Melalui Barang Kiriman",modul4a:"Modul 4A: Penyelundupan Melalui Kendaraan Darat (SUV)",modul4b:"Modul 4B: Penyelundupan Melalui Kapal Laut Cargo",evaluasi:"Ujian Evaluasi Modus Penyelundupan Narkotika"};n&&(n.textContent=i[e]||"Modul Inspeksi DJBC")}}class R{constructor(){this.container=document.getElementById("modal-root")}render(){const e=u.getConfig(),t=`
      <div id="lrs-modal-backdrop" class="modal-backdrop open">
        <div class="modal-card animate-slide-up">
          <div class="modal-header">
            <div style="display: flex; align-items: center; gap: 10px;">
              <span style="font-size: 1.3rem;">⚙️</span>
              <h3 style="margin: 0; font-size: 1.1rem; color: #FFF;">Pengaturan LRS / xAPI Analytics</h3>
            </div>
            <button id="close-lrs-modal-btn" class="btn-icon" style="width:32px; height:32px;">✕</button>
          </div>

          <form id="lrs-config-form">
            <p style="font-size: 0.82rem; color: var(--text-secondary); margin-bottom: 16px;">
              Masukkan detail Learning Record Store (LRS) untuk mengirim analytics interaksi peserta secara real-time via xAPI.
            </p>

            <div class="form-group">
              <label for="lrs-endpoint">LRS Endpoint URL</label>
              <input type="url" id="lrs-endpoint" class="form-control" 
                     placeholder="https://lrs.kemenkeu.go.id/xAPI/" 
                     value="${e.endpoint||""}" required>
            </div>

            <div class="form-group">
              <label for="lrs-username">LRS Basic Auth Username / Key</label>
              <input type="text" id="lrs-username" class="form-control" 
                     placeholder="Contoh: djbc_lms_key" 
                     value="${e.username||""}" required>
            </div>

            <div class="form-group">
              <label for="lrs-password">LRS Basic Auth Password / Secret</label>
              <input type="password" id="lrs-password" class="form-control" 
                     placeholder="••••••••••••••••" 
                     value="${e.password||""}" required>
            </div>

            <div class="form-group" style="flex-direction: row; align-items: center; gap: 10px; margin-top: 10px;">
              <input type="checkbox" id="lrs-enabled" ${e.enabled?"checked":""}>
              <label for="lrs-enabled" style="margin: 0; cursor: pointer;">Aktifkan Pengiriman xAPI Statement</label>
            </div>

            <div id="lrs-test-status" style="margin: 12px 0; font-size: 0.82rem; display: none; padding: 8px 12px; border-radius: 6px;"></div>

            <div style="display: flex; align-items: center; justify-content: flex-end; gap: 12px; margin-top: 20px;">
              <button type="button" id="test-lrs-btn" class="btn btn-outline">Uji Koneksi</button>
              <button type="submit" class="btn btn-gold">Simpan Pengaturan</button>
            </div>
          </form>
        </div>
      </div>
    `;this.container.innerHTML=t,this.attachEvents()}attachEvents(){const e=document.getElementById("lrs-modal-backdrop"),t=document.getElementById("close-lrs-modal-btn"),n=document.getElementById("lrs-config-form"),i=document.getElementById("test-lrs-btn"),a=document.getElementById("lrs-test-status"),s=()=>{e.classList.remove("open"),setTimeout(()=>{this.container.innerHTML=""},300)};t.addEventListener("click",s),e.addEventListener("click",o=>{o.target===e&&s()}),i.addEventListener("click",async()=>{const o=document.getElementById("lrs-endpoint").value,c=document.getElementById("lrs-username").value,r=document.getElementById("lrs-password").value;a.style.display="block",a.style.background="rgba(255, 149, 0, 0.2)",a.style.color="#FFB340",a.innerText="Menguji koneksi ke LRS...";const d=await u.testConnection(o,c,r);d.success?(a.style.background="rgba(52, 199, 89, 0.2)",a.style.color="#5CD97D",a.innerText=d.message):(a.style.background="rgba(255, 59, 48, 0.2)",a.style.color="#FF6B6B",a.innerText=d.message)}),n.addEventListener("submit",o=>{o.preventDefault();const c=document.getElementById("lrs-endpoint").value,r=document.getElementById("lrs-username").value,d=document.getElementById("lrs-password").value,v=document.getElementById("lrs-enabled").checked;u.saveConfig(c,r,d,v);const f=document.getElementById("lrs-status-dot");f&&(f.style.background=v?"#34C759":"#64748B"),s()})}}class V{static async init(){console.log("[App] Initializing Interactive Narcotics Concealment Inspection Simulator..."),m.init(),await g.init();const e=document.getElementById("lrs-config-btn"),t=document.getElementById("lrs-status-dot");t&&(t.style.background=u.isConfigured()?"#34C759":"#64748B"),e&&e.addEventListener("click",()=>{new R().render()});const n=document.getElementById("sidebar"),i=document.getElementById("sidebar-toggle-btn");i&&n&&i.addEventListener("click",()=>{n.classList.toggle("collapsed")});const a=document.getElementById("content-area");new D(a).init(),window.addEventListener("beforeunload",()=>{m.terminate()})}}document.addEventListener("DOMContentLoaded",()=>{V.init()});
//# sourceMappingURL=index-CXX5hFpf.js.map
